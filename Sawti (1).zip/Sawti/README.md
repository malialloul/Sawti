# Sawti (صوتي)

Android app that re-sings a nasheed or song in the user's own voice, fully on-device.
Record your voice → pick an engine and download its models in the app → pick a song (with or without music) → convert → trim, add reverb, export audio or a vertical video.

Kotlin + Jetpack Compose, ONNX Runtime for inference, Media3 Transformer for video. UI strings are Lebanese Arabic, right-to-left.

## Get the APK from GitHub

The workflow in `.github/workflows/android.yml` runs the unit tests and builds a release APK on every push.

1. Create a GitHub repo and push this folder to its `main` branch.
2. Every push builds an APK; download it from the run's page under **Actions → Build APK → Artifacts**.
3. To publish a release, push a tag:
   ```
   git tag v0.1.0
   git push origin v0.1.0
   ```
   The APK is attached to a new release on the repo's **Releases** page.

### Signing (recommended)

Without a key, CI signs with a throwaway debug key, so each new APK can't install over the previous one (you'd have to uninstall first). To sign with your own key, once:

```
keytool -genkeypair -v -keystore sawti.jks -alias sawti -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 sawti.jks > sawti.jks.b64        # macOS: base64 -i sawti.jks -o sawti.jks.b64
```

Then in the repo: **Settings → Secrets and variables → Actions → New repository secret**, add:

| Secret | Value |
|---|---|
| `SAWTI_KEYSTORE_BASE64` | contents of `sawti.jks.b64` |
| `SAWTI_KEYSTORE_PASSWORD` | the keystore password |
| `SAWTI_KEY_ALIAS` | `sawti` |
| `SAWTI_KEY_PASSWORD` | the key password |

Keep `sawti.jks` safe and out of git (`.gitignore` already excludes it). Losing it means users must reinstall.

## Build locally

Open the folder in Android Studio (Ladybug or newer). If it asks for a Gradle wrapper, run `gradle wrapper` once in the project root. Run on a real arm64 phone with 6 GB+ RAM.

## Engines and models

Step 2 offers two engines. Models are downloaded inside the app with one tap (or imported from files; the app works out which model each file is). The INTERNET permission is used only for these downloads; audio never leaves the phone.

**بلا تدريب (zero-shot, default).** OpenVoice v2 tone-colour converter. The user's recordings are turned into a 256-dim voice fingerprint (averaged over ~10 s voiced pieces, cached until the recordings change), the song's vocals give the source fingerprint, and the converter swaps them on the spectrogram, so melody and timing are kept. Ten seconds of recordings work; a minute or two is steadier. Output is 22.05 kHz and the model was trained on speech, so singing is weaker than a trained RVC model. Pitch shifting uses a phase vocoder before conversion.

| Model | Size | Source |
|---|---|---|
| Voice converter | 41 MB (int8) | [tone_converter_q8.onnx](https://huggingface.co/TigreGotico/voiceclonnx-openvoice-v2) (MIT) |
| Voice fingerprint encoder | 3 MB | tone_ref_encoder.onnx, same repo |

**نموذج مدرّب (RVC).** Best quality; needs a voice model trained off the phone.

| Model | Size | Notes |
|---|---|---|
| Voice (required) | — | RVC v2 synthesizer for *this* voice, exported to ONNX. Inputs `feats/p_len/pitch/pitchf/sid` (voice-changer) or `phone/phone_lengths/pitch/pitchf/ds/rnd` (RVC WebUI). Added from files. |
| ContentVec (required) | 379 MB | `contentvec-f.onnx` from wok000/weights_gpl |
| RMVPE (optional) | 362 MB | `rmvpe_20231006.onnx` from wok000/weights_gpl. Without it the app uses YIN. |

**Music separator (optional, both engines).** UVR MDX-Net, default [Kim_Vocal_2.onnx](https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/Kim_Vocal_2.onnx) (66 MB). Identified like UVR does (MD5 of the file's last 10,000 KiB) against 35 known vocal/instrumental models; unknown files get guessed settings and a warning.

### Making an RVC voice model

1. With the RVC engine selected, step 1 shows "Save recordings for training", which writes a zip of WAVs to `Download/Sawti`. Record 10+ minutes, reading and singing.
2. Train an RVC v2 model with Applio or RVC WebUI (Colab is fine), 40 kHz, with pitch.
3. Export to ONNX and add it with "Add files from the phone".

## How conversion works

1. **Separation** (only when "the song has music" is on): resample to 44.1 kHz, MDX-Net in 6 s chunks with 25% Hann-weighted overlap, exactly as UVR's `demix`. Vocals go to RVC; the backing track is kept. The result is cached, so changing the pitch and converting again doesn't re-separate.
2. **Voice conversion**. *Zero-shot*: resample to 22.05 kHz, optional pitch shift, OpenVoice converter in ~10 s chunks with 0.5 s context and crossfades. *RVC*: resample to 16 kHz, 8 s chunks with 0.5 s context and 100 ms crossfades, ContentVec features (upsampled 2× to 100 fps), RMVPE or YIN pitch shifted by the semitone setting and quantised to RVC's 255 bins, synthesizer, stitch. With music on, pitch moves only in whole octaves so the voice stays in key with the backing track.
3. **Edit and render**: trim, reverb and level on the voice, then the voice is brought to 44.1 kHz and mixed with the backing track (kept at 44.1 kHz), fades, WAV.

## Code map

```
audio/      WavIO, AudioDecoder (MediaCodec), VoiceRecorder, Resampler (polyphase sinc), Dsp
ml/core/    Fft (mixed radix), Stft (torch-compatible), LinearSpec (OpenVoice), PitchShifter,
            VoicedAudio, MdxDemixer, PitchMath, YinPitchTracker, Chunking, Half — pure Kotlin, unit-tested
ml/         Ort helpers, OpenVoiceConverter, RvcVoiceConverter, ContentEncoder, PitchExtractors,
            MdxNetSeparator, MdxModelTable, ModelStore (engines, detection), ModelDownloader
video/      VideoExporter (image + audio → 720×1280 H.264/AAC), CoverArt
storage/    MediaSaver (Music/Sawti, Movies/Sawti, Download/Sawti)
ui/         MainViewModel, SawtiApp (5-step screen), Components, theme
```

## Status

Verified while building:

- The pure-Kotlin core (`app/src/test`, run in CI): WAV, resampling, YIN within 1% from 110 to 880 Hz, RVC coarse pitch identical to the Python formula, chunk stitching, fp16, FFT against a naive DFT, STFT round trip.
- STFT output matches a numpy port of `torch.stft` to 1e-13, and the OpenVoice spectrogram matches a numpy port of `spectrogram_torch` exactly.
- The pitch shifter lands within 1% of the target pitch for −12 to +12 semitones and keeps the length.
- The full Kotlin MDX pipeline driven by the real Kim_Vocal_2 model matches a numpy port of UVR's demix to 1e-7, and on a 14 s speech-plus-music test mix it lifts vocal SDR from 0 dB to 17.2 dB.
- The Android, ONNX Runtime, ViewModel and Media3 code compiles against `android.jar` and API stubs.

Not verified: the OpenVoice and RVC engines have not run with their real models here (Hugging Face is blocked in the build sandbox); the code follows the published input/output specs. The Compose UI is only compiled in CI, and nothing has run on a phone yet. Speed on a phone is unknown: one Kim_Vocal_2 call took about 8 s on the 2-core sandbox CPU, and a 30 s clip needs about 8 calls.

## Roadmap

- A singing-trained zero-shot engine once one is light enough for phones (Seed-VC is too heavy today).
- Run separation and conversion in a foreground service so long clips survive leaving the app.
- Feature-index retrieval (RVC `.index`) for closer timbre.
- Checksums for downloaded models, and a cancel button for downloads.
- Re-enable R8 shrinking with tested keep rules.

## Credits

MDX-Net demixing follows UVR (Ultimate Vocal Remover) and python-audio-separator; model settings come from UVR's public model data. Check each model's own license before distributing it.
