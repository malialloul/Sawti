package com.sawti.app.ml.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * Linear magnitude spectrogram identical to OpenVoice's `spectrogram_torch(..., center=False)`:
 * reflect-pad (nFft - hop) / 2 on both sides, periodic Hann window, sqrt(re^2 + im^2 + 1e-6).
 * Output is bin-major: index = bin * frames + frame. Not thread-safe.
 */
class LinearSpec(val nFft: Int = 1024, val hop: Int = 256) {
    val bins = nFft / 2 + 1
    private val pad = (nFft - hop) / 2
    private val fft = Fft(nFft)
    private val window = DoubleArray(nFft) { 0.5 - 0.5 * cos(2 * PI * it / nFft) }
    private val zr = DoubleArray(nFft)
    private val zi = DoubleArray(nFft)

    fun frames(length: Int): Int {
        val padded = length + 2 * pad
        return if (padded < nFft) 0 else 1 + (padded - nFft) / hop
    }

    fun compute(x: FloatArray): FloatArray {
        require(x.size > pad) { "Audio too short for a spectrogram" }
        val frames = frames(x.size)
        val out = FloatArray(bins * frames)
        var t = 0
        while (t < frames) {
            val t2 = t + 1
            for (i in 0 until nFft) {
                val w = window[i]
                zr[i] = reflect(x, t * hop - pad + i) * w
                zi[i] = if (t2 < frames) reflect(x, t2 * hop - pad + i) * w else 0.0
            }
            fft.forward(zr, zi)
            for (k in 0 until bins) {
                val nk = if (k == 0) 0 else nFft - k
                val ar = (zr[k] + zr[nk]) * 0.5
                val ai = (zi[k] - zi[nk]) * 0.5
                out[k * frames + t] = sqrt(ar * ar + ai * ai + 1e-6).toFloat()
                if (t2 < frames) {
                    val br = (zi[k] + zi[nk]) * 0.5
                    val bi = (zr[nk] - zr[k]) * 0.5
                    out[k * frames + t2] = sqrt(br * br + bi * bi + 1e-6).toFloat()
                }
            }
            t += 2
        }
        return out
    }

    /** Bin-major [bins * frames] to frame-major [frames * bins]. */
    fun transpose(spec: FloatArray): FloatArray {
        val frames = spec.size / bins
        val out = FloatArray(spec.size)
        for (k in 0 until bins) for (f in 0 until frames) out[f * bins + k] = spec[k * frames + f]
        return out
    }

    private fun reflect(x: FloatArray, idx: Int): Double {
        val last = x.size - 1
        var i = idx
        if (i < 0) i = -i
        if (i > last) i = 2 * last - i
        return x[i].toDouble()
    }
}
