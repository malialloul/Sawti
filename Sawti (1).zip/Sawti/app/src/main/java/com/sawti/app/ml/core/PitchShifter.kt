package com.sawti.app.ml.core

import com.sawti.app.audio.Resampler
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Pitch shift that keeps duration: phase-vocoder time stretch, then resampling.
 * Used by the zero-shot engine, which (unlike RVC) has no pitch input of its own.
 */
object PitchShifter {

    fun shift(x: FloatArray, sampleRate: Int, semitones: Int, nFft: Int = 2048, analysisHop: Int = 256): FloatArray {
        if (semitones == 0 || x.size < nFft) return x
        val ratio = 2.0.pow(semitones / 12.0)
        val synthesisHop = max(1, (analysisHop * ratio).roundToInt())
        val stretched = timeStretch(x, nFft, analysisHop, synthesisHop)
        // Played back faster by the same factor, the stretched signal regains its length at the new pitch.
        val virtualRate = (sampleRate.toLong() * synthesisHop / analysisHop).toInt()
        val y = Resampler.resample(stretched, virtualRate, sampleRate)
        return FloatArray(x.size) { if (it < y.size) y[it] else 0f }
    }

    /** Classic phase vocoder; output length is about x.size * synthesisHop / analysisHop. */
    fun timeStretch(x: FloatArray, nFft: Int, analysisHop: Int, synthesisHop: Int): FloatArray {
        val half = nFft / 2
        val fft = Fft(nFft)
        val window = DoubleArray(nFft) { 0.5 - 0.5 * cos(2 * PI * it / nFft) }
        val bins = half + 1
        val frames = 1 + (x.size + nFft) / analysisHop
        val outLen = (frames - 1) * synthesisHop + nFft
        val ola = DoubleArray(outLen)
        val env = DoubleArray(outLen)
        val prevPhase = DoubleArray(bins)
        val sumPhase = DoubleArray(bins)
        val re = DoubleArray(nFft)
        val im = DoubleArray(nFft)
        val mag = DoubleArray(bins)
        val scale = synthesisHop.toDouble() / analysisHop

        for (t in 0 until frames) {
            val start = t * analysisHop - half
            for (i in 0 until nFft) {
                val j = start + i
                re[i] = if (j >= 0 && j < x.size) x[j] * window[i] else 0.0
                im[i] = 0.0
            }
            fft.forward(re, im)
            for (k in 0 until bins) {
                mag[k] = sqrt(re[k] * re[k] + im[k] * im[k])
                val phase = kotlin.math.atan2(im[k], re[k])
                if (t == 0) {
                    sumPhase[k] = phase
                } else {
                    val expected = 2 * PI * k * analysisHop / nFft
                    var dev = phase - prevPhase[k] - expected
                    dev -= 2 * PI * Math.rint(dev / (2 * PI))
                    sumPhase[k] += (expected + dev) * scale
                }
                prevPhase[k] = phase
            }
            for (k in 0 until bins) {
                re[k] = mag[k] * cos(sumPhase[k])
                im[k] = mag[k] * kotlin.math.sin(sumPhase[k])
                if (k in 1 until half) {
                    re[nFft - k] = re[k]
                    im[nFft - k] = -im[k]
                }
            }
            im[0] = 0.0
            im[half] = 0.0
            fft.inverse(re, im)
            val off = t * synthesisHop
            for (i in 0 until nFft) {
                val w = window[i]
                ola[off + i] += re[i] * w
                env[off + i] += w * w
            }
        }
        val skip = (half * scale).roundToInt()
        val n = (x.size * scale).roundToInt()
        return FloatArray(n) { i ->
            val j = i + skip
            if (j < outLen && env[j] > 1e-6) (ola[j] / env[j]).toFloat() else 0f
        }
    }
}
