package com.sawti.app.ml.core

import com.sawti.app.audio.FloatArrayBuilder
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

/** Simple energy-based voice activity: keeps the sung/spoken parts and drops pauses and silence. */
object VoicedAudio {

    /** Concatenates 20 ms frames whose level is within [relDb] of the loudest frame. */
    fun keepVoiced(x: FloatArray, sampleRate: Int, relDb: Double = -30.0, absMin: Double = 0.003): FloatArray {
        val f = sampleRate / 50
        val n = x.size / f
        if (n == 0) return FloatArray(0)
        val rms = DoubleArray(n) { i ->
            var s = 0.0
            for (j in i * f until (i + 1) * f) s += x[j].toDouble() * x[j]
            sqrt(s / f)
        }
        val thr = max(absMin, (rms.maxOrNull() ?: 0.0) * 10.0.pow(relDb / 20))
        val out = FloatArrayBuilder(x.size)
        for (i in 0 until n) if (rms[i] >= thr) out.addAll(x, i * f, f)
        return out.toArray()
    }

    /** Splits into pieces of about [segSec], dropping a final piece shorter than [minSec]. */
    fun segments(x: FloatArray, sampleRate: Int, segSec: Double = 10.0, minSec: Double = 2.0): List<FloatArray> {
        val seg = (segSec * sampleRate).toInt()
        val min = (minSec * sampleRate).toInt()
        val list = ArrayList<FloatArray>()
        var s = 0
        while (s < x.size) {
            val e = minOf(x.size, s + seg)
            if (e - s >= min) list += x.copyOfRange(s, e)
            s = e
        }
        return list
    }
}
