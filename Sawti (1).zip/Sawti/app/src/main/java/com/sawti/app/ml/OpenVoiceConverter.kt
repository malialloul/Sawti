package com.sawti.app.ml

import ai.onnxruntime.OnnxTensor
import com.sawti.app.audio.FloatArrayBuilder
import com.sawti.app.audio.PcmAudio
import com.sawti.app.audio.Resampler
import com.sawti.app.audio.WavIO
import com.sawti.app.ml.core.Chunking
import com.sawti.app.ml.core.LinearSpec
import com.sawti.app.ml.core.PitchShifter
import com.sawti.app.ml.core.VoicedAudio
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.FloatBuffer
import kotlin.math.roundToInt

/**
 * Zero-shot engine: OpenVoice v2 tone-colour converter (no training).
 * The user's recordings give a 256-dim voice fingerprint (averaged over ~10 s voiced pieces);
 * the song's vocals give the source fingerprint; the converter swaps one for the other on the
 * spectrogram, so the melody and timing of the original singing are kept.
 */
class OpenVoiceConverter(
    converterFile: File,
    encoderFile: File,
    takes: List<File>,
    cacheDir: File,
) : VoiceConverter {

    private val converter = Ort.open(converterFile)
    private val encoder = Ort.open(encoderFile)
    private val io = ModelIO(converter)
    private val encoderInput = encoder.inputNames.first()
    private val spec = LinearSpec(N_FFT, HOP)
    private val target: FloatArray

    override val description = "OpenVoice v2"

    init {
        val missing = listOf("spec", "spec_lengths", "src_g", "tgt_g").filter { it !in io.inputs }
        if (missing.isNotEmpty()) {
            close()
            throw UnsupportedModelException("Not an OpenVoice converter (missing $missing)")
        }
        target = try {
            targetFingerprint(takes, cacheDir, encoderFile.length())
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    override fun convert(vocals: PcmAudio, settings: ConversionSettings, onProgress: (Float) -> Unit): PcmAudio {
        var x = Resampler.resample(vocals, SR).samples
        if (settings.semitones != 0) x = PitchShifter.shift(x, SR, settings.semitones)
        val source = fingerprint(x) ?: target // a silent clip has nothing to convert
        val totalFrames = x.size / HOP
        require(totalFrames >= 20) { "Clip is too short" }

        val plan = Chunking.plan(totalFrames, CHUNK_FRAMES, OVERLAP_FRAMES, PAD_FRAMES)
        val pieces = ArrayList<FloatArray>(plan.size)
        var spf = 0
        for ((i, c) in plan.withIndex()) {
            val seg = x.copyOfRange(c.padStart * HOP, c.padEnd * HOP)
            val (out, frames) = runConverter(seg, source)
            if (spf == 0) spf = (out.size.toFloat() / frames).roundToInt().coerceAtLeast(1)
            pieces += Chunking.sliceOrPad(out, (c.coreStart - c.padStart) * spf, (c.coreEnd - c.padStart) * spf)
            onProgress((i + 1f) / plan.size)
        }
        val audio = Chunking.overlapAdd(pieces, plan.map { it.coreStart * spf }, totalFrames * spf, OVERLAP_FRAMES * spf)
        return PcmAudio(audio, SR * spf / HOP)
    }

    private fun runConverter(seg: FloatArray, source: FloatArray): Pair<FloatArray, Int> {
        val s = spec.compute(seg)
        val frames = s.size / spec.bins
        val tensors = LinkedHashMap<String, OnnxTensor>()
        try {
            tensors["spec"] = io.floats("spec", s, longArrayOf(1, spec.bins.toLong(), frames.toLong()))
            tensors["spec_lengths"] = io.longs("spec_lengths", longArrayOf(frames.toLong()), longArrayOf(1))
            tensors["src_g"] = io.floats("src_g", source, longArrayOf(1, DIM.toLong(), 1))
            tensors["tgt_g"] = io.floats("tgt_g", target, longArrayOf(1, DIM.toLong(), 1))
            converter.run(tensors).use { r -> return (r.get(0) as OnnxTensor).readFloats() to frames }
        } finally {
            tensors.values.forEach { it.close() }
        }
    }

    /** Average fingerprint over the voiced parts of [x] (22.05 kHz), or null if there is no voice. */
    private fun fingerprint(x: FloatArray): FloatArray? {
        val pieces = VoicedAudio.segments(VoicedAudio.keepVoiced(x, SR), SR)
        if (pieces.isEmpty()) return null
        val acc = FloatArray(DIM)
        for (p in pieces) {
            val e = embed(p)
            for (i in 0 until DIM) acc[i] += e[i]
        }
        for (i in 0 until DIM) acc[i] /= pieces.size
        return acc
    }

    private fun embed(piece: FloatArray): FloatArray {
        val s = spec.transpose(spec.compute(piece))
        val frames = s.size / spec.bins
        OnnxTensor.createTensor(Ort.env, FloatBuffer.wrap(s), longArrayOf(1, frames.toLong(), spec.bins.toLong())).use { input ->
            encoder.run(mapOf(encoderInput to input)).use { r ->
                val e = (r.get(0) as OnnxTensor).readFloats()
                require(e.size == DIM) { "Unexpected fingerprint size ${e.size}" }
                return e
            }
        }
    }

    /** The user's fingerprint, cached until the recordings (or the encoder) change. */
    private fun targetFingerprint(takes: List<File>, cacheDir: File, encoderSize: Long): FloatArray {
        val key = takes.sortedBy { it.name }.joinToString("|") { "${it.name}:${it.length()}" } + "|enc:$encoderSize|v1"
        val keyFile = File(cacheDir, "openvoice_voice.key")
        val dataFile = File(cacheDir, "openvoice_voice.bin")
        if (keyFile.exists() && keyFile.readText() == key && dataFile.length() == DIM * 4L) {
            DataInputStream(dataFile.inputStream().buffered()).use { d -> return FloatArray(DIM) { d.readFloat() } }
        }
        // Use up to ~5 minutes of recordings; more adds little to an averaged fingerprint.
        val all = FloatArrayBuilder(SR * 60)
        for (f in takes.sortedBy { it.name }) {
            if (all.size > SR * 300) break
            all.addAll(Resampler.resample(WavIO.read(f), SR).samples)
        }
        val fp = fingerprint(all.toArray()) ?: throw UnsupportedModelException("No voice found in the recordings")
        DataOutputStream(dataFile.outputStream().buffered()).use { d -> fp.forEach { d.writeFloat(it) } }
        keyFile.writeText(key)
        return fp
    }

    override fun close() {
        runCatching { converter.close() }
        runCatching { encoder.close() }
    }

    companion object {
        const val SR = 22050
        private const val N_FFT = 1024
        private const val HOP = 256          // one frame = 256 samples (~11.6 ms)
        private const val DIM = 256
        private const val CHUNK_FRAMES = 860 // ~10 s per call
        private const val OVERLAP_FRAMES = 8 // ~90 ms crossfade
        private const val PAD_FRAMES = 43    // ~0.5 s context each side
    }
}
