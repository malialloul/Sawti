package com.sawti.app.ml

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CancellationException

/** Downloads a model file. Only models travel over the network; audio never leaves the phone. */
object ModelDownloader {

    fun download(url: String, dest: File, keepGoing: () -> Boolean, onProgress: (Float) -> Unit) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = 0L
                    var reported = 0L
                    while (true) {
                        if (!keepGoing()) throw CancellationException("Download cancelled")
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0 && done - reported > 256 * 1024) {
                            onProgress(done.toFloat() / total)
                            reported = done
                        }
                    }
                    if (total > 0 && done != total) throw IOException("Download incomplete")
                }
            }
        } catch (e: Exception) {
            dest.delete()
            throw e
        } finally {
            conn.disconnect()
        }
    }
}
