package com.sawti.app.ml

import ai.onnxruntime.TensorInfo
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File

private const val HF = "https://huggingface.co"

enum class ModelSlot(val fileName: String, val downloadUrl: String?, val sizeMbHint: Int) {
    TONE_CONVERTER("tone_converter.onnx", "$HF/TigreGotico/voiceclonnx-openvoice-v2/resolve/main/tone_converter_q8.onnx?download=true", 41),
    TONE_ENCODER("tone_ref_encoder.onnx", "$HF/TigreGotico/voiceclonnx-openvoice-v2/resolve/main/tone_ref_encoder.onnx?download=true", 3),
    VOICE("voice_rvc.onnx", null, 0),
    CONTENT("content_encoder.onnx", "$HF/wok000/weights_gpl/resolve/main/content-vec/contentvec-f.onnx?download=true", 379),
    PITCH("pitch_rmvpe.onnx", "$HF/wok000/weights_gpl/resolve/main/rmvpe/rmvpe_20231006.onnx?download=true", 362),
    SEPARATOR("separator_mdx.onnx", "https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/Kim_Vocal_2.onnx", 66),
}

/** The two ways of turning a song into the user's voice. */
enum class Engine(val required: List<ModelSlot>, val optional: List<ModelSlot>) {
    /** OpenVoice: uses the recordings directly, everything on the phone. */
    ZERO_SHOT(listOf(ModelSlot.TONE_CONVERTER, ModelSlot.TONE_ENCODER), listOf(ModelSlot.SEPARATOR)),
    /** RVC: best quality, needs a voice model trained off the phone. */
    TRAINED(listOf(ModelSlot.VOICE, ModelSlot.CONTENT), listOf(ModelSlot.PITCH, ModelSlot.SEPARATOR)),
}

/** Keeps models in app-private storage and works out which model a file is. */
class ModelStore(private val context: Context) {
    private val dir = File(context.filesDir, "models").apply { mkdirs() }
    private val separatorInfo = File(dir, "separator_mdx.json")

    fun file(slot: ModelSlot) = File(dir, slot.fileName)

    fun sizeMb(slot: ModelSlot): Int? = file(slot).takeIf { it.length() > 0 }?.let { maxOf(1, (it.length() / 1_048_576).toInt()) }

    fun has(slot: ModelSlot) = file(slot).length() > 0

    fun isReady(engine: Engine) = engine.required.all { has(it) }

    class Installed(val slot: ModelSlot, val recognised: Boolean)

    /** Imports a file the user picked; the slot is detected from the model itself. */
    fun importUri(uri: Uri): Installed {
        val tmp = File(dir, "incoming.part")
        context.contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { input.copyTo(it, 1 shl 20) }
        } ?: error("Cannot read file")
        return install(tmp, displayName(uri), expected = null)
    }

    fun download(slot: ModelSlot, keepGoing: () -> Boolean, onProgress: (Float) -> Unit): Installed {
        val url = slot.downloadUrl ?: error("No download for $slot")
        val tmp = File(dir, slot.fileName + ".download")
        ModelDownloader.download(url, tmp, keepGoing, onProgress)
        return install(tmp, url.substringAfterLast('/').substringBefore('?'), expected = slot)
    }

    private fun install(tmp: File, name: String, expected: ModelSlot?): Installed {
        val slot: ModelSlot
        var recognised = true
        try {
            slot = detect(tmp)
            if (expected != null && slot != expected) throw UnsupportedModelException("Downloaded file is not the expected model")
            if (slot == ModelSlot.SEPARATOR) {
                val dimF = MdxNetSeparator.probeDimF(tmp)
                val (params, exact) = MdxModelTable.lookup(MdxModelTable.uvrHash(tmp), dimF, name)
                recognised = exact
                separatorInfo.writeText(
                    JSONObject()
                        .put("nFft", params.nFft).put("dimF", params.dimF).put("dimT", params.dimT)
                        .put("compensate", params.compensate.toDouble()).put("vocals", params.primaryIsVocals)
                        .toString(),
                )
            }
        } catch (e: UnsupportedModelException) {
            tmp.delete()
            throw e
        } catch (e: Exception) {
            tmp.delete()
            throw UnsupportedModelException("Not a valid ONNX model")
        }
        val dest = file(slot)
        dest.delete()
        check(tmp.renameTo(dest)) { "Could not save model" }
        return Installed(slot, recognised)
    }

    /** Identifies a model by its inputs and outputs. */
    private fun detect(file: File): ModelSlot = Ort.open(file).use { s ->
        val inputs = s.inputInfo
        val names = inputs.keys
        fun shape(name: String) = (inputs.getValue(name).info as? TensorInfo)?.shape ?: LongArray(0)
        val single = names.singleOrNull()?.let { shape(it) }
        val outShapes = s.outputInfo.values.mapNotNull { (it.info as? TensorInfo)?.shape }
        when {
            names.containsAll(listOf("spec", "spec_lengths", "src_g", "tgt_g")) -> ModelSlot.TONE_CONVERTER
            single != null && single.size == 3 && single[2] == 513L -> ModelSlot.TONE_ENCODER
            "feats" in names || "phone" in names -> ModelSlot.VOICE
            single != null && single.size == 4 && single[1] == 4L -> ModelSlot.SEPARATOR
            names.any { "thresh" in it.lowercase() } || outShapes.any { it.lastOrNull() == 360L } -> ModelSlot.PITCH
            single != null && single.size in 1..3 -> ModelSlot.CONTENT
            else -> throw UnsupportedModelException("Unknown model (inputs: $names)")
        }
    }

    fun createConverter(engine: Engine, takes: List<File>): VoiceConverter = when (engine) {
        Engine.ZERO_SHOT -> OpenVoiceConverter(
            converterFile = file(ModelSlot.TONE_CONVERTER),
            encoderFile = file(ModelSlot.TONE_ENCODER),
            takes = takes,
            cacheDir = dir,
        )
        Engine.TRAINED -> RvcVoiceConverter(
            contentFile = file(ModelSlot.CONTENT),
            voiceFile = file(ModelSlot.VOICE),
            pitchFile = file(ModelSlot.PITCH).takeIf { it.length() > 0 },
        )
    }

    fun createSeparator(): VocalSeparator {
        val o = JSONObject(separatorInfo.readText())
        val params = MdxParams(
            nFft = o.getInt("nFft"),
            dimF = o.getInt("dimF"),
            dimT = o.getInt("dimT"),
            compensate = o.getDouble("compensate").toFloat(),
            primaryIsVocals = o.getBoolean("vocals"),
        )
        return MdxNetSeparator(file(ModelSlot.SEPARATOR), params)
    }

    private fun displayName(uri: Uri): String =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: ""
}
