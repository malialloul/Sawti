package com.sawti.app.ui

import android.app.Application
import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sawti.app.R
import com.sawti.app.audio.AudioDecoder
import com.sawti.app.audio.Dsp
import com.sawti.app.audio.PcmAudio
import com.sawti.app.audio.Resampler
import com.sawti.app.audio.VoiceRecorder
import com.sawti.app.audio.WavIO
import com.sawti.app.ml.ConversionSettings
import com.sawti.app.ml.Engine
import com.sawti.app.ml.ModelSlot
import com.sawti.app.ml.ModelStore
import com.sawti.app.ml.NoSeparation
import com.sawti.app.ml.UnsupportedModelException
import com.sawti.app.ml.Separated
import com.sawti.app.ml.VoiceConverter
import com.sawti.app.storage.MediaSaver
import com.sawti.app.video.CoverArt
import com.sawti.app.video.VideoExporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.min
import kotlin.math.roundToInt

data class TakeInfo(val file: File, val seconds: Float)

class AudioView(val title: String, val durationSec: Float, val peaks: FloatArray)

data class Busy(@StringRes val label: Int, val progress: Float? = null)

data class CoverColors(val background: Int, val accent: Int, val text: Int)

data class UiState(
    val takes: List<TakeInfo> = emptyList(),
    val recording: Boolean = false,
    val recordSeconds: Float = 0f,
    val recordLevel: Float = 0f,
    val models: Map<ModelSlot, Int?> = emptyMap(),
    val engine: Engine = Engine.ZERO_SHOT,
    val song: AudioView? = null,
    val songRange: ClosedFloatingPointRange<Float> = 0f..0f,
    val semitones: Int = 0,
    val withMusic: Boolean = false,
    val engineInfo: String? = null,
    val result: AudioView? = null,
    val resultRange: ClosedFloatingPointRange<Float> = 0f..0f,
    val reverb: Float = 0.2f,
    val volumeDb: Float = 0f,
    val fade: Boolean = true,
    val musicLevel: Float = 1f,
    val hasMusicTrack: Boolean = false,
    val coverUri: Uri? = null,
    val playing: String? = null,
    val busy: Busy? = null,
)

sealed interface UiEvent {
    data class Message(val text: String) : UiEvent
    data class Share(val uri: Uri, val mime: String) : UiEvent
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val ctx: Application = application
    private val modelStore = ModelStore(application)
    private val takesDir = File(application.filesDir, "voice_takes").apply { mkdirs() }
    private val workDir = File(application.cacheDir, "work").apply { mkdirs() }
    private val prefs = application.getSharedPreferences("sawti", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    private var song: PcmAudio? = null
    private var rawResult: PcmAudio? = null
    private var instrumental: PcmAudio? = null
    private var separated: Separated? = null
    private var separatedKey: String? = null
    private var songToken = 0
    private var converter: VoiceConverter? = null
    private var converterEngine: Engine? = null
    private var player: MediaPlayer? = null
    private val recordingFlag = AtomicBoolean(false)

    init {
        val saved = prefs.getString("engine", null)
        val engine = Engine.entries.firstOrNull { it.name == saved } ?: Engine.ZERO_SHOT
        _state.update { it.copy(engine = engine) }
        refreshTakes()
        refreshModels()
    }

    // ---- Step 1: record ----

    fun toggleRecording() {
        if (recordingFlag.get()) {
            recordingFlag.set(false)
            return
        }
        if (_state.value.busy != null) return
        stopPlayback()
        recordingFlag.set(true)
        _state.update { it.copy(recording = true, recordSeconds = 0f, recordLevel = 0f) }
        viewModelScope.launch {
            try {
                val audio = VoiceRecorder().record({ recordingFlag.get() }) { peak, sec ->
                    _state.update { it.copy(recordLevel = peak, recordSeconds = sec) }
                }
                if (audio.durationSec >= 1.0) withContext(Dispatchers.IO) {
                    WavIO.write(File(takesDir, "take_${System.currentTimeMillis()}.wav"), audio)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                fail(e)
            } finally {
                recordingFlag.set(false)
                _state.update { it.copy(recording = false, recordLevel = 0f) }
                refreshTakes()
            }
        }
    }

    fun onMicDenied() = message(R.string.mic_denied)

    fun deleteTake(take: TakeInfo) {
        if (_state.value.playing == KEY_TAKE + take.file.name) stopPlayback()
        take.file.delete()
        refreshTakes()
    }

    fun exportDataset() = launchBusy(R.string.busy_packing) {
        val takes = _state.value.takes
        if (takes.isEmpty()) return@launchBusy
        val zip = File(workDir, "voice_dataset.zip")
        val uri = withContext(Dispatchers.IO) {
            ZipOutputStream(zip.outputStream().buffered()).use { z ->
                for (t in takes) {
                    z.putNextEntry(ZipEntry(t.file.name))
                    t.file.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            MediaSaver.save(ctx, zip, "sawti_voice_${stamp()}.zip", "application/zip", MediaSaver.Kind.DOWNLOAD)
        }
        message(R.string.saved_dataset)
        _events.emit(UiEvent.Share(uri, "application/zip"))
    }

    // ---- Step 2: models ----

    fun setEngine(engine: Engine) {
        if (_state.value.busy != null) return
        prefs.edit().putString("engine", engine.name).apply()
        closeConverter()
        _state.update { it.copy(engine = engine) }
    }

    /** Imports any number of .onnx files; each one's role is detected from the model itself. */
    fun importModels(uris: List<Uri>) {
        if (uris.isEmpty()) return
        launchBusy(R.string.busy_importing) {
            closeConverter()
            var added = 0
            var guessed = false
            for (uri in uris) {
                try {
                    val r = withContext(Dispatchers.IO) { modelStore.importUri(uri) }
                    if (r.slot == ModelSlot.SEPARATOR) separatedKey = null
                    if (!r.recognised) guessed = true
                    added++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    fail(e)
                }
            }
            refreshModels()
            if (guessed) message(R.string.model_guessed)
            else if (added > 0) _events.tryEmit(UiEvent.Message(ctx.getString(R.string.models_added, added)))
        }
    }

    /** Downloads a model straight into the app. */
    fun downloadModel(slot: ModelSlot) = launchBusy(R.string.busy_downloading) {
        closeConverter()
        _state.update { it.copy(busy = Busy(R.string.busy_downloading, 0f)) }
        val r = withContext(Dispatchers.IO) {
            modelStore.download(slot, keepGoing = { isActive }) { p ->
                _state.update { it.copy(busy = Busy(R.string.busy_downloading, p)) }
            }
        }
        if (r.slot == ModelSlot.SEPARATOR) separatedKey = null
        refreshModels()
        message(if (r.recognised) R.string.model_added else R.string.model_guessed)
    }

    // ---- Step 3: song ----

    fun loadSong(uri: Uri) = launchBusy(R.string.busy_reading) {
        val pcm = withContext(Dispatchers.IO) { AudioDecoder.decode(ctx, uri) }
        require(pcm.samples.isNotEmpty()) { ctx.getString(R.string.error_empty_audio) }
        song = pcm
        songToken++
        rawResult = null
        instrumental = null
        separated = null
        separatedKey = null
        val dur = pcm.durationSec.toFloat()
        _state.update {
            it.copy(
                song = AudioView(displayName(uri), dur, Dsp.peaks(pcm.samples)),
                songRange = 0f..min(dur, DEFAULT_CLIP_SEC),
                result = null,
                hasMusicTrack = false,
            )
        }
    }

    fun setSongRange(r: ClosedFloatingPointRange<Float>) {
        val old = _state.value.songRange
        var s = r.start
        var e = r.endInclusive
        if (e - s > MAX_CLIP_SEC) {
            if (s != old.start) e = s + MAX_CLIP_SEC else s = e - MAX_CLIP_SEC
        }
        _state.update { it.copy(songRange = s..e) }
    }

    // ---- Step 4: convert ----

    fun setWithMusic(on: Boolean) = _state.update { s ->
        // With a backing track only whole-octave shifts stay in tune with the music.
        s.copy(withMusic = on, semitones = if (on) (s.semitones / 12.0).roundToInt() * 12 else s.semitones)
    }

    fun stepSemitones(direction: Int) = _state.update { s ->
        val step = if (s.withMusic) 12 else 1
        s.copy(semitones = (s.semitones + direction * step).coerceIn(-12, 12))
    }

    fun convert() {
        val src = song ?: return message(R.string.need_song)
        val s0 = _state.value
        val engine = s0.engine
        if (!modelStore.isReady(engine)) {
            return message(if (engine == Engine.ZERO_SHOT) R.string.need_models_zero else R.string.need_models)
        }
        if (engine == Engine.ZERO_SHOT && s0.takes.sumOf { it.seconds.toDouble() } < MIN_TAKES_SEC) {
            return message(R.string.need_takes)
        }
        if (s0.withMusic && !modelStore.has(ModelSlot.SEPARATOR)) return message(R.string.need_separator)
        val range = s0.songRange
        if (range.endInclusive - range.start < 1f) return message(R.string.clip_too_short)
        val settings = ConversionSettings(semitones = s0.semitones)
        val withMusic = s0.withMusic
        val key = "$songToken:${range.start}:${range.endInclusive}"

        launchBusy(R.string.busy_loading_models) {
            val clip = src.slice(range.start.toDouble(), range.endInclusive.toDouble())
            val parts = when {
                !withMusic -> NoSeparation.separate(clip) {}
                separatedKey == key -> separated!!
                else -> {
                    _state.update { it.copy(busy = Busy(R.string.busy_separating, 0f)) }
                    withContext(Dispatchers.Default) {
                        // Closed straight after use so its memory is free before the voice models load.
                        modelStore.createSeparator().use { sep ->
                            sep.separate(clip) { p -> _state.update { it.copy(busy = Busy(R.string.busy_separating, p)) } }
                        }
                    }.also {
                        separated = it
                        separatedKey = key
                    }
                }
            }

            if (converterEngine != engine) closeConverter()
            _state.update { it.copy(busy = Busy(if (engine == Engine.ZERO_SHOT) R.string.busy_preparing else R.string.busy_loading_models)) }
            val takeFiles = _state.value.takes.map { it.file }
            val conv = converter ?: withContext(Dispatchers.Default) { modelStore.createConverter(engine, takeFiles) }.also {
                converter = it
                converterEngine = engine
            }
            _state.update { it.copy(busy = Busy(R.string.busy_converting, 0f)) }
            val out = withContext(Dispatchers.Default) {
                val converted = conv.convert(parts.vocals, settings) { p ->
                    _state.update { it.copy(busy = Busy(R.string.busy_converting, p)) }
                }
                // The backing track stays at 44.1 kHz; the voice is brought up to that rate when rendering.
                val music = parts.instrumental?.let { Resampler.resample(it, OUTPUT_RATE) }
                instrumental = music
                // Keep the original vocal/music balance when there is a backing track.
                val target = if (music != null) Dsp.peak(parts.vocals.samples).coerceIn(0.1f, 0.95f) else 0.9f
                Dsp.normalize(converted.samples, target)
                converted
            }
            rawResult = out
            val dur = out.durationSec.toFloat()
            _state.update {
                it.copy(
                    result = AudioView(it.song?.title.orEmpty(), dur, Dsp.peaks(out.samples)),
                    resultRange = 0f..dur,
                    engineInfo = conv.description + if (withMusic) " + MDX-Net" else "",
                    hasMusicTrack = instrumental != null,
                )
            }
        }
    }

    // ---- Step 5: edit + export ----

    fun setResultRange(r: ClosedFloatingPointRange<Float>) = _state.update { it.copy(resultRange = r) }
    fun setReverb(v: Float) = _state.update { it.copy(reverb = v) }
    fun setVolume(db: Float) = _state.update { it.copy(volumeDb = db) }
    fun setFade(on: Boolean) = _state.update { it.copy(fade = on) }
    fun setMusicLevel(v: Float) = _state.update { it.copy(musicLevel = v) }
    fun setCover(uri: Uri) = _state.update { it.copy(coverUri = uri) }

    fun exportAudio() = launchBusy(R.string.busy_exporting) {
        val (file, _) = renderFinal()
        val uri = withContext(Dispatchers.IO) {
            MediaSaver.save(ctx, file, "sawti_${stamp()}.wav", "audio/x-wav", MediaSaver.Kind.AUDIO)
        }
        message(R.string.saved_audio)
        _events.emit(UiEvent.Share(uri, "audio/*"))
    }

    fun exportVideo(colors: CoverColors) = launchBusy(R.string.busy_video) {
        val (audio, durationMs) = renderFinal()
        val chosen = _state.value.coverUri
        val image: Uri
        val mime: String?
        if (chosen != null) {
            image = chosen
            mime = ctx.contentResolver.getType(chosen)
        } else {
            val s = _state.value
            val cover = withContext(Dispatchers.Default) {
                CoverArt.generate(
                    File(workDir, "cover.png"), s.song?.title.orEmpty(), s.result?.peaks ?: FloatArray(0),
                    colors.background, colors.accent, colors.text,
                )
            }
            image = Uri.fromFile(cover)
            mime = "image/png"
        }
        val mp4 = File(workDir, "video.mp4")
        VideoExporter.export(ctx, image, mime, audio, durationMs, mp4) // main thread, as Transformer requires
        val uri = withContext(Dispatchers.IO) {
            MediaSaver.save(ctx, mp4, "sawti_${stamp()}.mp4", "video/mp4", MediaSaver.Kind.VIDEO)
        }
        message(R.string.saved_video)
        _events.emit(UiEvent.Share(uri, "video/mp4"))
    }

    /** Applies trim + effects, mixes the music at 44.1 kHz and writes a WAV (AAC encoders reject 40 kHz). */
    private suspend fun renderFinal(): Pair<File, Long> = withContext(Dispatchers.Default) {
        val r = rawResult ?: error(ctx.getString(R.string.need_convert))
        val s = _state.value
        val from = s.resultRange.start.toDouble()
        val to = s.resultRange.endInclusive.toDouble()
        var voice = Dsp.reverb(r.slice(from, to).samples, r.sampleRate, s.reverb)
        voice = Dsp.gainDb(voice, s.volumeDb)
        val x = Resampler.resample(voice, r.sampleRate, OUTPUT_RATE)
        instrumental?.let { Dsp.mixInto(x, it.slice(from, to).samples, s.musicLevel) }
        if (s.fade) Dsp.fade(x, OUTPUT_RATE, 0.25, 0.8)
        Dsp.normalize(x, 0.98f, onlyIfLouder = true)
        val pcm = PcmAudio(x, OUTPUT_RATE)
        val file = File(workDir, "final.wav")
        WavIO.write(file, pcm)
        file to (pcm.durationSec * 1000).toLong()
    }

    // ---- Playback ----

    fun togglePlay(key: String) {
        if (_state.value.playing == key) {
            stopPlayback()
            return
        }
        if (_state.value.busy != null || recordingFlag.get()) return
        viewModelScope.launch {
            try {
                val file = when {
                    key == KEY_SONG -> {
                        val src = song ?: return@launch
                        val r = _state.value.songRange
                        withContext(Dispatchers.Default) {
                            File(workDir, "song_preview.wav").also {
                                WavIO.write(it, src.slice(r.start.toDouble(), r.endInclusive.toDouble()))
                            }
                        }
                    }
                    key == KEY_RESULT -> renderFinal().first
                    key.startsWith(KEY_TAKE) -> File(takesDir, key.removePrefix(KEY_TAKE))
                    else -> return@launch
                }
                startPlayback(file, key)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                fail(e)
            }
        }
    }

    private fun startPlayback(file: File, key: String) {
        stopPlayback()
        player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            setOnCompletionListener { stopPlayback() }
            prepare()
            start()
        }
        _state.update { it.copy(playing = key) }
    }

    fun stopPlayback() {
        player?.let {
            runCatching { it.stop() }
            it.release()
        }
        player = null
        _state.update { it.copy(playing = null) }
    }

    // ---- Helpers ----

    private fun launchBusy(@StringRes label: Int, block: suspend () -> Unit) {
        if (_state.value.busy != null || recordingFlag.get()) return
        stopPlayback()
        _state.update { it.copy(busy = Busy(label)) }
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                fail(e)
            } finally {
                _state.update { it.copy(busy = null) }
            }
        }
    }

    private fun refreshTakes() {
        val takes = takesDir.listFiles { f -> f.extension == "wav" }.orEmpty()
            .sortedBy { it.name }
            .map { TakeInfo(it, (it.length() - 44).coerceAtLeast(0) / (2f * 44100f)) }
        val changed = takes.map { it.file.name } != _state.value.takes.map { it.file.name }
        _state.update { it.copy(takes = takes) }
        // The zero-shot voice fingerprint is built from the recordings.
        if (changed && converterEngine == Engine.ZERO_SHOT) closeConverter()
    }

    private fun refreshModels() {
        _state.update { s -> s.copy(models = ModelSlot.entries.associateWith { modelStore.sizeMb(it) }) }
    }

    private fun closeConverter() {
        converter?.close()
        converter = null
        converterEngine = null
    }

    private fun message(@StringRes res: Int) {
        _events.tryEmit(UiEvent.Message(ctx.getString(res)))
    }

    private fun fail(e: Throwable) {
        val detail = when (e) {
            is OutOfMemoryError -> ctx.getString(R.string.error_memory)
            is UnsupportedModelException -> e.message
            else -> e.message ?: e.javaClass.simpleName
        }
        _events.tryEmit(UiEvent.Message(ctx.getString(R.string.error_prefix, detail)))
    }

    private fun displayName(uri: Uri): String =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null
        } ?: ctx.getString(R.string.untitled)

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    override fun onCleared() {
        recordingFlag.set(false)
        stopPlayback()
        closeConverter()
    }

    companion object {
        const val KEY_SONG = "song"
        const val KEY_RESULT = "result"
        const val KEY_TAKE = "take:"
        const val DEFAULT_CLIP_SEC = 30f
        const val MAX_CLIP_SEC = 60f
        const val OUTPUT_RATE = 44100
        const val MIN_TAKES_SEC = 10.0
    }
}
