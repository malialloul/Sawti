package com.sawti.app

import com.sawti.app.audio.Dsp
import com.sawti.app.audio.PcmAudio
import com.sawti.app.audio.Resampler
import com.sawti.app.audio.WavIO
import com.sawti.app.ml.core.Chunking
import com.sawti.app.ml.core.Fft
import com.sawti.app.ml.core.Half
import com.sawti.app.ml.core.LinearSpec
import com.sawti.app.ml.core.MdxDemixer
import com.sawti.app.ml.core.PitchMath
import com.sawti.app.ml.core.PitchShifter
import com.sawti.app.ml.core.Stft
import com.sawti.app.ml.core.VoicedAudio
import com.sawti.app.ml.core.YinPitchTracker
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Runs on the JVM in CI (gradle testDebugUnitTest); covers the pure-Kotlin audio/ML core. */
class CoreTest {

    private fun sine(freq: Double, sr: Int, sec: Double, amp: Float = 0.5f) =
        FloatArray((sr * sec).toInt()) { (amp * sin(2 * PI * freq * it / sr)).toFloat() }

    private fun zeroCrossFreq(x: FloatArray, sr: Int): Double {
        var c = 0
        for (i in 1 until x.size) if (x[i - 1] < 0 && x[i] >= 0) c++
        return c * sr.toDouble() / x.size
    }

    @Test fun wavRoundTrip() {
        val s = sine(440.0, 44100, 0.5)
        val out = ByteArrayOutputStream()
        WavIO.write(out, PcmAudio(s, 44100))
        val r = WavIO.read(out.toByteArray())
        assertEquals(44100, r.sampleRate)
        assertEquals(s.size, r.samples.size)
        assertEquals(s[1234], r.samples[1234], 1e-4f)
    }

    @Test fun resamplerKeepsPitchAndLevel() {
        for ((a, b) in listOf(44100 to 16000, 16000 to 44100, 40000 to 44100, 48000 to 16000)) {
            val y = Resampler.resample(sine(440.0, a, 2.0), a, b)
            val mid = y.copyOfRange(y.size / 4, 3 * y.size / 4)
            assertEquals(440.0, zeroCrossFreq(mid, b), 2.0)
            assertEquals(0.5f, Dsp.peak(mid), 0.02f)
        }
        val alias = Resampler.resample(sine(12000.0, 44100, 1.0), 44100, 16000)
        assertTrue(Dsp.peak(alias.copyOfRange(2000, 14000)) < 0.01f)
    }

    @Test fun yinFindsPitch() {
        for (f in listOf(110.0, 220.0, 523.25, 880.0)) {
            val f0 = YinPitchTracker().track(sine(f, 16000, 1.0, 0.3f))
            val inner = f0.copyOfRange(10, f0.size - 10).sorted()
            assertEquals(f, inner[inner.size / 2].toDouble(), f * 0.01)
        }
        assertTrue(YinPitchTracker().track(FloatArray(16000)).all { it == 0f })
    }

    @Test fun coarsePitchMatchesRvc() {
        // Values from RVC's Python formula for 0, 50, 100, 220, 440, 1100, 2000 Hz.
        val c = PitchMath.toCoarse(floatArrayOf(0f, 50f, 100f, 220f, 440f, 1100f, 2000f))
        assertArrayEquals(longArrayOf(1, 1, 20, 60, 122, 255, 255), c)
    }

    @Test fun chunksReassemble() {
        for (total in listOf(37, 800, 2345, 6000)) {
            val plan = Chunking.plan(total, 800, 10, 50)
            val pieces = plan.map { FloatArray((it.coreEnd - it.coreStart) * 400) { 1f } }
            val y = Chunking.overlapAdd(pieces, plan.map { it.coreStart * 400 }, total * 400, 4000)
            assertTrue(y.all { abs(it - 1f) < 1e-3f })
        }
    }

    @Test fun halfPrecision() {
        for (v in floatArrayOf(0f, 1f, -2.5f, 0.333f, 65504f, 123.456f)) {
            assertEquals(v, Half.toFloat(Half.fromFloat(v)), max(abs(v) * 1e-3f, 1e-6f))
        }
    }

    @Test fun fftMatchesNaiveDft() {
        for (n in listOf(2, 3, 5, 7, 12, 30, 60, 7680)) {
            val rnd = java.util.Random(n.toLong())
            val xr = DoubleArray(n) { rnd.nextGaussian() }
            val xi = DoubleArray(n) { rnd.nextGaussian() }
            val fr = xr.copyOf(); val fi = xi.copyOf()
            Fft(n).forward(fr, fi)
            for (k in listOf(0, 1, n / 2, n - 1)) {
                var sr = 0.0; var si = 0.0
                for (j in 0 until n) {
                    val a = -2 * PI * ((j.toLong() * k) % n) / n
                    sr += xr[j] * cos(a) - xi[j] * sin(a)
                    si += xr[j] * sin(a) + xi[j] * cos(a)
                }
                assertTrue(hypot(sr - fr[k], si - fi[k]) < 1e-8 * n)
            }
        }
    }

    @Test fun stftRoundTrip() {
        val st = Stft(7680, 1024)
        val x = FloatArray(1024 * 255) { (sin(it * 0.01) * 0.5).toFloat() }
        val (re, im) = st.forward(x)
        val y = st.inverse(re, im, st.bins, st.frames(x.size), x.size)
        for (i in x.indices) assertEquals(x[i], y[i], 1e-4f)
    }

    @Test fun mdxDemixWithIdentityModelReturnsInput() {
        val dm = MdxDemixer(7680, 3072, 256)
        val sig = sine(440.0, 44100, 8.0, 0.4f)
        val out = dm.demix(sig, { it })
        // UVR's algorithm itself deviates slightly at the very ends; check the body.
        for (i in 4410 until sig.size - 4410) assertEquals(sig[i], out[i], 2e-3f)
    }

    @Test fun openVoiceSpectrogramMatchesDirectDft() {
        val x = FloatArray(4000) { (0.3 * sin(it * 0.05) + ((it * 7919) % 13) / 130.0).toFloat() }
        val ls = LinearSpec()
        val spec = ls.compute(x)
        val frames = ls.frames(x.size)
        assertEquals(1 + (x.size + 768 - 1024) / 256, frames)
        for (t in listOf(0, 3, frames - 1)) for (k in listOf(0, 5, 100, 512)) {
            var re = 0.0
            var im = 0.0
            for (i in 0 until 1024) {
                var j = t * 256 - 384 + i
                if (j < 0) j = -j
                if (j > x.size - 1) j = 2 * (x.size - 1) - j
                val w = 0.5 - 0.5 * cos(2 * PI * i / 1024)
                val a = -2 * PI * k * i / 1024
                re += x[j] * w * cos(a)
                im += x[j] * w * sin(a)
            }
            val want = sqrt(re * re + im * im + 1e-6).toFloat()
            assertEquals(want, spec[k * frames + t], 1e-3f * max(1f, want))
        }
    }

    @Test fun pitchShiftMovesPitchAndKeepsLength() {
        val sr = 22050
        val tone = sine(220.0, sr, 2.0, 0.3f)
        for (st in listOf(12, -12, 4)) {
            val y = PitchShifter.shift(tone, sr, st)
            assertEquals(tone.size, y.size)
            val f0 = YinPitchTracker().track(Resampler.resample(y.copyOfRange(sr / 2, sr * 3 / 2), sr, 16000))
                .filter { it > 0 }.sorted()
            val want = 220 * 2.0.pow(st / 12.0)
            assertEquals(want, f0[f0.size / 2].toDouble(), want * 0.01)
        }
    }

    @Test fun voiceActivityDropsSilence() {
        val sr = 22050
        val x = FloatArray(sr * 4) { i -> if (i < sr * 2) (0.3 * sin(2 * PI * 200 * i / sr)).toFloat() else 0.0005f }
        val kept = VoicedAudio.keepVoiced(x, sr)
        assertTrue(abs(kept.size - sr * 2) <= sr / 50)
        assertEquals(listOf(10, 10, 5), VoicedAudio.segments(FloatArray(sr * 25), sr).map { it.size / sr })
    }
}
