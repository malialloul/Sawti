# Sawti (صوتي)

Android app that re-sings a nasheed or song in the user's own voice, fully on-device.
Record your voice → add your models → pick a song (with or without music) → convert → trim, add reverb, export audio or a vertical video.

Kotlin + Jetpack Compose, ONNX Runtime for inference, Media3 Transformer for video. UI strings are Lebanese Arabic, right-to-left.

## Get the APK from GitHub

The workflow in `.github/workflows/android.yml` runs the unit tests and builds a release APK on every push.

1. Create a GitHub repo and push this folder to its `main` branch.
2. Every push builds an APK; download it from the run's page under **Actions → Build APK → Artifacts**.
3. To publish a release, push a tag:
   ```
   git tag v0.1.0
   git push origin v0.1.0
   ```
   The APK is attached to a new release on the repo's **Releases** page.

### Signing (recommended)

Without a key, CI signs with a throwaway debug key, so each new APK can't install over the previous one (you'd have to uninstall first). To sign with your own key, once:

```
keytool -genkeypair -v -keystore sawti.jks -alias sawti -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 sawti.jks > sawti.jks.b64        # macOS: base64 -i sawti.jks -o sawti.jks.b64
```

Then in the repo: **Settings → Secrets and variables → Actions → New repository secret**, add:

| Secret | Value |
|---|---|
| `SAWTI_KEYSTORE_BASE64` | contents of `sawti.jks.b64` |
| `SAWTI_KEYSTORE_PASSWORD` | the keystore password |
| `SAWTI_KEY_ALIAS` | `sawti` |
| `SAWTI_KEY_PASSWORD` | the key password |

Keep `sawti.jks` safe and out of git (`.gitignore` already excludes it). Losing it means users must reinstall.

## Build locally

Open the folder in Android Studio (Ladybug or newer). If it asks for a Gradle wrapper, run `gradle wrapper` once in the project root. Run on a real arm64 phone with 6 GB+ RAM.

## Models

Nothing is bundled; the user adds ONNX files in step 2 (copied into app-private storage):

| Slot | What | Notes |
|---|---|---|
| Voice (required) | RVC v2 synthesizer for *this* voice, exported to ONNX | Inputs `feats/p_len/pitch/pitchf/sid` (voice-changer export) or `phone/phone_lengths/pitch/pitchf/ds/rnd` (RVC WebUI export). fp32 or fp16. Output sample rate detected automatically. |
| Content (required) | ContentVec / HuBERT encoder, 16 kHz waveform in | The output whose last dim matches the voice model (768 for v2) is used. |
| Pitch (optional) | RMVPE ONNX taking a **waveform** | Outputs F0 or the 360-bin salience map. Without it the app uses a built-in YIN tracker. |
| Music separator (optional) | UVR MDX-Net ONNX | Needed only for songs with music. Recommended: [Kim_Vocal_2.onnx](https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/Kim_Vocal_2.onnx) (66 MB). |

The separator is identified the way UVR does it (MD5 of the file's last 10,000 KiB), with STFT settings for 35 known vocal/instrumental MDX-Net models taken from UVR's public model data. Unknown files get guessed settings and a warning.

### Making the voice model

RVC needs a model trained on the user's voice, and training needs a GPU, so it happens off the phone:

1. In step 1 the user records 10+ minutes (reading and singing). "Save recordings for training" writes a zip of WAVs to `Download/Sawti`.
2. Train an RVC v2 model from it with Applio or RVC WebUI (Colab is fine), 40 kHz, with pitch.
3. Export to ONNX and add it in step 2.

The in-app recorder exists so the dataset is the user's own voice, recorded with their consent.

## How conversion works

1. **Separation** (only when "the song has music" is on): resample to 44.1 kHz, MDX-Net in 6 s chunks with 25% Hann-weighted overlap, exactly as UVR's `demix`. Vocals go to RVC; the backing track is kept. The result is cached, so changing the pitch and converting again doesn't re-separate.
2. **RVC**: resample to 16 kHz, 8 s chunks with 0.5 s context and 100 ms crossfades, ContentVec features (upsampled 2× to 100 fps), RMVPE or YIN pitch shifted by the semitone setting and quantised to RVC's 255 bins, synthesizer, stitch. With music on, pitch moves only in whole octaves so the voice stays in key with the backing track.
3. **Edit and render**: trim, reverb and level on the voice, music level, fades, then a 44.1 kHz WAV (AAC encoders reject RVC's 40 kHz).

## Code map

```
audio/      WavIO, AudioDecoder (MediaCodec), VoiceRecorder, Resampler (polyphase sinc), Dsp
ml/core/    Fft (mixed radix), Stft (torch-compatible), MdxDemixer, PitchMath, YinPitchTracker,
            Chunking, Half                                   — pure Kotlin, unit-tested
ml/         Ort helpers, ContentEncoder, PitchExtractors, RvcVoiceConverter, MdxNetSeparator,
            MdxModelTable, ModelStore, VoiceConverter + VocalSeparator interfaces
video/      VideoExporter (image + audio → 720×1280 H.264/AAC), CoverArt
storage/    MediaSaver (Music/Sawti, Movies/Sawti, Download/Sawti)
ui/         MainViewModel, SawtiApp (5-step screen), Components, theme
```

## Status

Verified while building:

- The pure-Kotlin core (`app/src/test`, run in CI): WAV, resampling, YIN within 1% from 110 to 880 Hz, RVC coarse pitch identical to the Python formula, chunk stitching, fp16, FFT against a naive DFT, STFT round trip.
- STFT output matches a numpy port of `torch.stft` to 1e-13.
- The full Kotlin MDX pipeline driven by the real Kim_Vocal_2 model matches a numpy port of UVR's demix to 1e-7, and on a 14 s speech-plus-music test mix it lifts vocal SDR from 0 dB to 17.2 dB.
- The Android, ONNX Runtime, ViewModel and Media3 code compiles against `android.jar` and API stubs.

Not verified: the Compose UI was never compiled in the sandbox (no access to Google's Maven), and nothing has run on a phone yet. The first CI run is the first full build; if it fails, the log points at the line. Speed on a phone is unknown: one Kim_Vocal_2 call took about 8 s on the 2-core sandbox CPU, and a 30 s clip needs about 8 calls.

## Roadmap

- Zero-shot engine (e.g. a Seed-VC export) implementing `VoiceConverter`, taking the recordings directly instead of a trained model.
- Run separation and conversion in a foreground service so long clips survive leaving the app.
- Feature-index retrieval (RVC `.index`) for closer timbre.
- In-app model downloader with checksums.
- Re-enable R8 shrinking with tested keep rules.

## Credits

MDX-Net demixing follows UVR (Ultimate Vocal Remover) and python-audio-separator; model settings come from UVR's public model data. Check each model's own license before distributing it.
