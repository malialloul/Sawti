package com.sawti.app.audio

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Small, dependency-free audio effects used by the editor. */
object Dsp {

    fun gainDb(x: FloatArray, db: Float): FloatArray {
        val g = 10.0.pow(db / 20.0).toFloat()
        return FloatArray(x.size) { x[it] * g }
    }

    /** In place: linear fade in/out. */
    fun fade(x: FloatArray, sampleRate: Int, inSec: Double, outSec: Double) {
        val nIn = min(x.size / 2, (inSec * sampleRate).toInt())
        val nOut = min(x.size / 2, (outSec * sampleRate).toInt())
        for (i in 0 until nIn) x[i] *= i.toFloat() / nIn
        for (i in 0 until nOut) x[x.size - 1 - i] *= i.toFloat() / nOut
    }

    fun peak(x: FloatArray): Float {
        var m = 0f
        for (v in x) m = max(m, abs(v))
        return m
    }

    /** In place: scale so the peak equals [target] (with [onlyIfLouder], only ever scales down). */
    fun normalize(x: FloatArray, target: Float = 0.95f, onlyIfLouder: Boolean = false) {
        val p = peak(x)
        if (p <= 1e-6f || (onlyIfLouder && p <= target)) return
        val g = target / p
        for (i in x.indices) x[i] *= g
    }

    /** In place: base += add * gain (add may be shorter or longer). */
    fun mixInto(base: FloatArray, add: FloatArray, gain: Float = 1f) {
        for (i in 0 until min(base.size, add.size)) base[i] += add[i] * gain
    }

    /** Freeverb-style room: 4 damped combs + 2 allpasses. [amount] 0..1. Output has the same length. */
    fun reverb(x: FloatArray, sampleRate: Int, amount: Float): FloatArray {
        if (amount <= 0.001f) return x.copyOf()
        val scale = sampleRate / 44100.0
        val combLens = intArrayOf(1116, 1277, 1422, 1557).map { max(1, (it * scale).toInt()) }
        val apLens = intArrayOf(556, 341).map { max(1, (it * scale).toInt()) }
        val feedback = 0.70f + 0.12f * amount
        val damp = 0.3f

        val wetSig = FloatArray(x.size)
        for (len in combLens) {
            val buf = FloatArray(len)
            var idx = 0
            var store = 0f
            for (i in x.indices) {
                val out = buf[idx]
                store = out * (1 - damp) + store * damp
                buf[idx] = x[i] * 0.25f + store * feedback
                idx = if (idx + 1 == len) 0 else idx + 1
                wetSig[i] += out
            }
        }
        for (len in apLens) {
            val buf = FloatArray(len)
            var idx = 0
            for (i in x.indices) {
                val bufOut = buf[idx]
                val input = wetSig[i]
                wetSig[i] = -input + bufOut
                buf[idx] = input + bufOut * 0.5f
                idx = if (idx + 1 == len) 0 else idx + 1
            }
        }
        val wet = amount * 0.9f
        val dry = 1f - amount * 0.3f
        return FloatArray(x.size) { x[it] * dry + wetSig[it] * wet }
    }

    /** Max-abs envelope in [bins] buckets, normalized to 0..1 (for drawing waveforms). */
    fun peaks(x: FloatArray, bins: Int = 160): FloatArray {
        if (x.isEmpty()) return FloatArray(0)
        val n = min(bins, x.size)
        val per = x.size / n
        val p = FloatArray(n) { b ->
            val s = b * per
            val e = if (b == n - 1) x.size else s + per
            var m = 0f
            for (i in s until e) m = max(m, abs(x[i]))
            m
        }
        val mx = p.maxOrNull() ?: 0f
        if (mx > 0f) for (i in p.indices) p[i] /= mx
        return p
    }
}
