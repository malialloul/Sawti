package com.sawti.app.ml

import com.sawti.app.audio.PcmAudio

data class ConversionSettings(
    /** Pitch shift applied to the melody, in semitones (12 = one octave). */
    val semitones: Int = 0,
    val speakerId: Int = 0,
)

/**
 * Turns a sung vocal into the user's voice. RVC is implemented today; a zero-shot engine
 * (reference clip instead of a trained model) can implement the same interface later.
 */
interface VoiceConverter : AutoCloseable {
    /** Short human-readable description of the engine, e.g. "RVC v2, RMVPE". */
    val description: String

    fun convert(vocals: PcmAudio, settings: ConversionSettings, onProgress: (Float) -> Unit): PcmAudio
}

/** Vocals plus the backing track (null when the song had no music to remove). */
class Separated(val vocals: PcmAudio, val instrumental: PcmAudio?)

/** Splits a song into vocals and backing track. */
interface VocalSeparator : AutoCloseable {
    fun separate(song: PcmAudio, onProgress: (Float) -> Unit): Separated
    override fun close() {}
}

/** For a cappella nasheeds: the whole file is the vocal. */
object NoSeparation : VocalSeparator {
    override fun separate(song: PcmAudio, onProgress: (Float) -> Unit) = Separated(song, null)
}
