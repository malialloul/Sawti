package com.sawti.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max

/** Records mono 44.1 kHz from the mic with minimal processing (good for voice-model datasets). */
class VoiceRecorder(private val sampleRate: Int = 44100) {

    /** Caller must hold RECORD_AUDIO. Stops when [keepGoing] returns false. */
    @SuppressLint("MissingPermission")
    suspend fun record(keepGoing: () -> Boolean, onLevel: (peak: Float, seconds: Float) -> Unit): PcmAudio =
        withContext(Dispatchers.IO) {
            val minBuf = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, // skips most AGC/noise suppression
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                max(minBuf, sampleRate / 5),
            )
            check(rec.state == AudioRecord.STATE_INITIALIZED) { "Microphone unavailable" }
            val data = FloatArrayBuilder(sampleRate * 20)
            val chunk = ShortArray(sampleRate / 20)
            rec.startRecording()
            try {
                while (keepGoing()) {
                    ensureActive()
                    val n = rec.read(chunk, 0, chunk.size)
                    if (n <= 0) continue
                    var peak = 0f
                    for (i in 0 until n) {
                        val v = chunk[i] / 32768f
                        data.add(v)
                        peak = max(peak, abs(v))
                    }
                    onLevel(peak, data.size.toFloat() / sampleRate)
                }
            } finally {
                runCatching { rec.stop() }
                rec.release()
            }
            PcmAudio(data.toArray(), sampleRate)
        }
}
