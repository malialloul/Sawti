package com.sawti.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sawti.app.R
import com.sawti.app.ml.ModelSlot
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SawtiApp(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val colors = MaterialTheme.colorScheme

    LaunchedEffect(vm) {
        vm.events.collect { e ->
            when (e) {
                is UiEvent.Message -> scope.launch { snackbar.showSnackbar(e.text) }
                is UiEvent.Share -> {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = e.mime
                        putExtra(Intent.EXTRA_STREAM, e.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(send, null))
                }
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleRecording() else vm.onMicDenied()
    }
    val songPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::loadSong)
    }
    var pendingSlot by remember { mutableStateOf<ModelSlot?>(null) }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val slot = pendingSlot
        pendingSlot = null
        if (uri != null && slot != null) vm.importModel(slot, uri)
    }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(vm::setCover)
    }

    val onRecord = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted || state.recording) vm.toggleRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }
    val idle = state.busy == null && !state.recording

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = { state.busy?.let { BusyBar(it) } },
            containerColor = colors.background,
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 28.dp),
            ) {
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.displaySmall, color = colors.primary)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.tagline), style = MaterialTheme.typography.bodyLarge, color = colors.onSurfaceVariant)
                Spacer(Modifier.height(36.dp))

                Step(1, stringResource(R.string.step_record), done = state.takes.isNotEmpty()) {
                    RecordStep(state, onRecord, vm, enabled = state.busy == null)
                }
                Step(2, stringResource(R.string.step_models), done = state.models[ModelSlot.VOICE] != null && state.models[ModelSlot.CONTENT] != null) {
                    ModelsStep(state, enabled = idle) { slot ->
                        pendingSlot = slot
                        modelPicker.launch(arrayOf("*/*"))
                    }
                }
                Step(3, stringResource(R.string.step_song), done = state.song != null) {
                    SongStep(state, vm, enabled = idle) { songPicker.launch(arrayOf("audio/*", "video/*")) }
                }
                Step(4, stringResource(R.string.step_convert), done = state.result != null, enabled = state.song != null) {
                    ConvertStep(state, vm, enabled = idle && state.song != null)
                }
                Step(5, stringResource(R.string.step_edit), done = false, enabled = state.result != null, last = true) {
                    EditStep(
                        state = state,
                        vm = vm,
                        enabled = idle,
                        onPickCover = {
                            coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        onExportVideo = {
                            vm.exportVideo(CoverColors(colors.primary.toArgb(), colors.tertiary.toArgb(), colors.onPrimary.toArgb()))
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun RecordStep(state: UiState, onRecord: () -> Unit, vm: MainViewModel, enabled: Boolean) {
    val c = MaterialTheme.colorScheme
    val prompts = stringArrayResource(R.array.record_prompts)
    Text(stringResource(R.string.record_hint), style = MaterialTheme.typography.bodyMedium, color = c.onSurfaceVariant)
    Spacer(Modifier.height(12.dp))
    Text(
        prompts[state.takes.size % prompts.size],
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, c.outlineVariant, RoundedCornerShape(12.dp))
            .padding(16.dp),
    )
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Button(
            onClick = onRecord,
            enabled = enabled,
            colors = if (state.recording) ButtonDefaults.buttonColors(containerColor = c.error, contentColor = c.onError) else ButtonDefaults.buttonColors(),
        ) {
            Icon(if (state.recording) Icons.Rounded.Stop else Icons.Rounded.Mic, null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(if (state.recording) R.string.record_stop else R.string.record_start))
        }
        if (state.recording) {
            Spacer(Modifier.width(14.dp))
            LevelMeter(state.recordLevel)
            Spacer(Modifier.width(10.dp))
            Text(formatTime(state.recordSeconds), style = MaterialTheme.typography.bodyMedium)
        }
    }
    if (state.takes.isNotEmpty()) {
        Spacer(Modifier.height(16.dp))
        val total = state.takes.sumOf { it.seconds.toDouble() }.toFloat()
        Text(
            stringResource(R.string.takes_summary, state.takes.size, formatTime(total)),
            style = MaterialTheme.typography.labelLarge,
        )
        state.takes.forEachIndexed { i, take ->
            val key = MainViewModel.KEY_TAKE + take.file.name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.take_label, i + 1, formatTime(take.seconds)),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { vm.togglePlay(key) }) {
                    Icon(if (state.playing == key) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, stringResource(R.string.play))
                }
                IconButton(onClick = { vm.deleteTake(take) }, enabled = !state.recording) {
                    Icon(Icons.Rounded.Delete, stringResource(R.string.delete), tint = c.onSurfaceVariant)
                }
            }
        }
        TextButton(onClick = vm::exportDataset, enabled = enabled && !state.recording) {
            Icon(Icons.Rounded.Download, null, Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.export_dataset))
        }
        Text(stringResource(R.string.dataset_hint), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
    }
}

@Composable
private fun ModelsStep(state: UiState, enabled: Boolean, onPick: (ModelSlot) -> Unit) {
    val c = MaterialTheme.colorScheme
    Text(stringResource(R.string.models_hint), style = MaterialTheme.typography.bodyMedium, color = c.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))
    for (slot in ModelSlot.entries) {
        val size = state.models[slot]
        val label = when (slot) {
            ModelSlot.VOICE -> R.string.model_voice
            ModelSlot.CONTENT -> R.string.model_content
            ModelSlot.PITCH -> R.string.model_pitch
            ModelSlot.SEPARATOR -> R.string.model_separator
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(label), style = MaterialTheme.typography.bodyLarge)
                Text(
                    if (size != null) stringResource(R.string.model_ready, size) else stringResource(R.string.model_missing),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (size != null) c.primary else c.onSurfaceVariant,
                )
            }
            OutlinedButton(onClick = { onPick(slot) }, enabled = enabled) {
                Text(stringResource(if (size != null) R.string.model_replace else R.string.model_add))
            }
        }
    }
    if (state.models[ModelSlot.PITCH] == null) {
        Text(stringResource(R.string.pitch_fallback), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
    }
    Spacer(Modifier.height(4.dp))
    Text(stringResource(R.string.separator_hint), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
}

@Composable
private fun SongStep(state: UiState, vm: MainViewModel, enabled: Boolean, onPick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    OutlinedButton(onClick = onPick, enabled = enabled) {
        Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(if (state.song == null) R.string.song_pick else R.string.song_change))
    }
    Spacer(Modifier.height(6.dp))
    Text(stringResource(R.string.song_hint), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.with_music), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = state.withMusic, onCheckedChange = vm::setWithMusic, enabled = enabled)
    }
    if (state.withMusic && state.models[ModelSlot.SEPARATOR] == null) {
        Text(stringResource(R.string.need_separator), style = MaterialTheme.typography.bodySmall, color = c.error)
    }
    state.song?.let { song ->
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.MusicNote, null, Modifier.size(18.dp), tint = c.tertiary)
            Spacer(Modifier.width(6.dp))
            Text(song.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(8.dp))
        WaveformRange(song.peaks, song.durationSec, state.songRange, vm::setSongRange)
        Text(
            stringResource(R.string.clip_length, formatTime(state.songRange.endInclusive - state.songRange.start)),
            style = MaterialTheme.typography.bodySmall,
            color = c.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        PlayButton(state.playing == MainViewModel.KEY_SONG, enabled = enabled || state.playing == MainViewModel.KEY_SONG) {
            vm.togglePlay(MainViewModel.KEY_SONG)
        }
    }
}

@Composable
private fun ConvertStep(state: UiState, vm: MainViewModel, enabled: Boolean) {
    val c = MaterialTheme.colorScheme
    Text(
        stringResource(if (state.withMusic) R.string.pitch_hint_music else R.string.pitch_hint),
        style = MaterialTheme.typography.bodySmall,
        color = c.onSurfaceVariant,
    )
    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(R.string.pitch_label), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        FilledTonalIconButton(onClick = { vm.stepSemitones(-1) }, enabled = enabled) {
            Icon(Icons.Rounded.Remove, null)
        }
        Text(
            stringResource(R.string.pitch_value, state.semitones),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = 64.dp),
        )
        FilledTonalIconButton(onClick = { vm.stepSemitones(+1) }, enabled = enabled) {
            Icon(Icons.Rounded.Add, null)
        }
    }
    Spacer(Modifier.height(14.dp))
    Button(onClick = vm::convert, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.convert))
    }
    state.engine?.let {
        Spacer(Modifier.height(6.dp))
        Text(it, style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
    }
}

@Composable
private fun EditStep(
    state: UiState,
    vm: MainViewModel,
    enabled: Boolean,
    onPickCover: () -> Unit,
    onExportVideo: () -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val result = state.result
    if (result == null) {
        Text(stringResource(R.string.edit_empty), style = MaterialTheme.typography.bodyMedium, color = c.onSurfaceVariant)
    } else {
        WaveformRange(result.peaks, result.durationSec, state.resultRange, vm::setResultRange)
        Spacer(Modifier.height(8.dp))
        PlayButton(state.playing == MainViewModel.KEY_RESULT, enabled = enabled || state.playing == MainViewModel.KEY_RESULT) {
            vm.togglePlay(MainViewModel.KEY_RESULT)
        }
        Spacer(Modifier.height(14.dp))
        LabeledSlider(
            stringResource(R.string.reverb), "${(state.reverb * 100).roundToInt()}%",
            state.reverb, 0f..1f, vm::setReverb,
        )
        LabeledSlider(
            stringResource(R.string.volume), "%+.0f dB".format(state.volumeDb),
            state.volumeDb, -12f..12f, vm::setVolume,
        )
        if (state.hasMusicTrack) {
            LabeledSlider(
                stringResource(R.string.music_level), "${(state.musicLevel * 100).roundToInt()}%",
                state.musicLevel, 0f..1.5f, vm::setMusicLevel,
            )
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.fade), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = state.fade, onCheckedChange = vm::setFade)
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = vm::exportAudio, enabled = enabled, modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.export_audio))
            }
            OutlinedButton(onClick = onExportVideo, enabled = enabled, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Movie, null, Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.export_video))
            }
        }
        TextButton(onClick = onPickCover, enabled = enabled) {
            Icon(Icons.Rounded.Image, null, Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(if (state.coverUri != null) R.string.cover_chosen else R.string.pick_cover))
        }
        if (state.coverUri == null) {
            Text(stringResource(R.string.cover_default), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
        }
    }
}

@Composable
private fun BusyBar(busy: Busy) {
    val c = MaterialTheme.colorScheme
    Surface(color = c.primary, contentColor = c.onPrimary) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
        ) {
            val p = busy.progress
            Text(
                if (p != null) stringResource(busy.label, (p * 100).roundToInt()) else stringResource(busy.label),
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(8.dp))
            if (p != null) {
                LinearProgressIndicator(
                    progress = { p },
                    modifier = Modifier.fillMaxWidth(),
                    color = c.onPrimary,
                    trackColor = c.onPrimary.copy(alpha = 0.25f),
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = c.onPrimary,
                    trackColor = c.onPrimary.copy(alpha = 0.25f),
                )
            }
        }
    }
}
