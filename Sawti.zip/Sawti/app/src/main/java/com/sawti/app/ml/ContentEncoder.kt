package com.sawti.app.ml

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.TensorInfo
import java.io.File

/**
 * ContentVec / HuBERT encoder: 16 kHz waveform -> per-frame content features (50 frames/s).
 * Works with the voice-changer style export (input [1,1,T] or [1,T]; several named outputs).
 */
class ContentEncoder(file: File) : AutoCloseable {
    private val session = Ort.open(file)
    private val io = ModelIO(session)
    private val inputName = session.inputNames.first()
    private val inputRank = io.info(inputName).shape.size

    class Features(val data: FloatArray, val frames: Int, val dim: Int)

    /** Picks the output whose last dimension matches the synthesizer (768 for RVC v2, 256 for v1). */
    private fun outputFor(dim: Int): String {
        val candidates = io.outputs.filter { (_, info) ->
            (info.info as? TensorInfo)?.shape?.lastOrNull() == dim.toLong()
        }.keys
        return candidates.firstOrNull { "12" in it && !it.endsWith("s") }
            ?: candidates.firstOrNull()
            ?: io.outputs.keys.first()
    }

    fun encode(x16: FloatArray, dim: Int): Features {
        val shape = if (inputRank == 3) longArrayOf(1, 1, x16.size.toLong()) else longArrayOf(1, x16.size.toLong())
        val outName = outputFor(dim)
        io.floats(inputName, x16, shape).use { input ->
            session.run(mapOf(inputName to input), setOf(outName)).use { result ->
                val t = result.get(0) as OnnxTensor
                val s = t.info.shape
                val raw = t.readFloats()
                // Expect [1, frames, dim]; transpose if the export gives [1, dim, frames].
                return if (s.size == 3 && s[2] != dim.toLong() && s[1] == dim.toLong()) {
                    val frames = s[2].toInt()
                    val out = FloatArray(raw.size)
                    for (d in 0 until dim) for (f in 0 until frames) out[f * dim + d] = raw[d * frames + f]
                    Features(out, frames, dim)
                } else {
                    val d = s.last().toInt()
                    if (d != dim) throw UnsupportedModelException("Content encoder gives $d-dim features, voice model expects $dim")
                    Features(raw, raw.size / d, d)
                }
            }
        }
    }

    override fun close() = session.close()
}
