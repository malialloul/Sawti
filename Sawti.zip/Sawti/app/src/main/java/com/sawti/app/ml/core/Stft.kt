package com.sawti.app.ml.core

import kotlin.math.PI
import kotlin.math.cos

/**
 * STFT / inverse STFT with the same conventions as torch.stft / torch.istft
 * (center = true, reflect padding, periodic Hann window, no normalisation).
 * Two real frames are packed into one complex FFT, so the work is halved.
 * Spectra are stored bin-major: index = bin * frames + frame. Not thread-safe.
 */
class Stft(val nFft: Int, val hop: Int) {
    val bins = nFft / 2 + 1
    private val fft = Fft(nFft)
    private val window = DoubleArray(nFft) { 0.5 - 0.5 * cos(2 * PI * it / nFft) }
    private val zr = DoubleArray(nFft)
    private val zi = DoubleArray(nFft)

    fun frames(length: Int) = 1 + length / hop

    /** Returns (re, im), each [keepBins * frames]. */
    fun forward(x: FloatArray, keepBins: Int = bins): Pair<FloatArray, FloatArray> {
        require(x.size > nFft / 2) { "Signal shorter than n_fft/2" }
        val frames = frames(x.size)
        val re = FloatArray(keepBins * frames)
        val im = FloatArray(keepBins * frames)
        val half = nFft / 2
        var t = 0
        while (t < frames) {
            val t2 = t + 1
            val start = t * hop - half
            for (i in 0 until nFft) {
                val w = window[i]
                zr[i] = reflect(x, start + i) * w
                zi[i] = if (t2 < frames) reflect(x, start + hop + i) * w else 0.0
            }
            fft.forward(zr, zi)
            for (k in 0 until keepBins) {
                val nk = if (k == 0) 0 else nFft - k
                val ar = zr[k]; val ai = zi[k]
                val br = zr[nk]; val bi = zi[nk]
                // A = (Z[k] + conj Z[n-k]) / 2 ; B = (Z[k] - conj Z[n-k]) / 2i
                re[k * frames + t] = ((ar + br) * 0.5).toFloat()
                im[k * frames + t] = ((ai - bi) * 0.5).toFloat()
                if (t2 < frames) {
                    re[k * frames + t2] = ((ai + bi) * 0.5).toFloat()
                    im[k * frames + t2] = ((br - ar) * 0.5).toFloat()
                }
            }
            t += 2
        }
        return re to im
    }

    /** Inverse of [forward]; bins >= keepBins are treated as zero. Returns [length] samples. */
    fun inverse(re: FloatArray, im: FloatArray, keepBins: Int, frames: Int, length: Int): FloatArray {
        val half = nFft / 2
        val olaLen = nFft + hop * (frames - 1)
        val ola = DoubleArray(olaLen)
        val env = DoubleArray(olaLen)
        var t = 0
        while (t < frames) {
            val t2 = t + 1
            zr.fill(0.0); zi.fill(0.0)
            for (k in 0 until minOf(keepBins, bins)) {
                val ar = re[k * frames + t].toDouble()
                var ai = im[k * frames + t].toDouble()
                var br = 0.0; var bi = 0.0
                if (t2 < frames) { br = re[k * frames + t2].toDouble(); bi = im[k * frames + t2].toDouble() }
                if (k == 0 || k == half) { ai = 0.0; bi = 0.0 } // irfft ignores these imaginary parts
                // Z = A + iB, with Hermitian mirror for the upper half
                zr[k] = ar - bi; zi[k] = ai + br
                if (k != 0 && k != half) {
                    zr[nFft - k] = ar + bi; zi[nFft - k] = br - ai
                }
            }
            fft.inverse(zr, zi)
            for (f in 0..1) {
                val tt = t + f
                if (tt >= frames) break
                val src = if (f == 0) zr else zi
                val off = tt * hop
                for (i in 0 until nFft) {
                    val w = window[i]
                    ola[off + i] += src[i] * w
                    env[off + i] += w * w
                }
            }
            t += 2
        }
        return FloatArray(length) { i ->
            val j = i + half
            if (j < olaLen && env[j] > 1e-11) (ola[j] / env[j]).toFloat() else 0f
        }
    }

    private fun reflect(x: FloatArray, idx: Int): Double {
        var i = idx
        val last = x.size - 1
        if (i < 0) i = -i
        if (i > last) i = 2 * last - i
        return x[i].toDouble()
    }
}
