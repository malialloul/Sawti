package com.sawti.app.ml.core

/** IEEE 754 half-precision conversions (for fp16 ONNX models). */
object Half {

    fun fromFloat(f: Float): Short {
        val bits = java.lang.Float.floatToIntBits(f)
        val sign = (bits ushr 16) and 0x8000
        var v = (bits and 0x7fffffff) + 0x1000
        if (v >= 0x47800000) {
            if ((bits and 0x7fffffff) >= 0x47800000) {
                if (v < 0x7f800000) return (sign or 0x7c00).toShort()
                return (sign or 0x7c00 or ((bits and 0x007fffff) ushr 13)).toShort()
            }
            return (sign or 0x7bff).toShort()
        }
        if (v >= 0x38800000) return (sign or ((v - 0x38000000) ushr 13)).toShort()
        if (v < 0x33000000) return sign.toShort()
        v = (bits and 0x7fffffff) ushr 23
        return (sign or ((((bits and 0x7fffff) or 0x800000) + (0x800000 ushr (v - 102))) ushr (126 - v))).toShort()
    }

    fun toFloat(h: Short): Float {
        val hb = h.toInt() and 0xffff
        var mant = hb and 0x03ff
        var exp = hb and 0x7c00
        if (exp == 0x7c00) {
            exp = 0x3fc00
        } else if (exp != 0) {
            exp += 0x1c000
        } else if (mant != 0) {
            exp = 0x1c400
            do {
                mant = mant shl 1
                exp -= 0x400
            } while ((mant and 0x400) == 0)
            mant = mant and 0x3ff
        }
        return java.lang.Float.intBitsToFloat(((hb and 0x8000) shl 16) or ((exp or mant) shl 13))
    }
}
