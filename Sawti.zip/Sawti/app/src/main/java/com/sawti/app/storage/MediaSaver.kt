package com.sawti.app.storage

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Saves finished files to the shared Music / Movies / Download folders (scoped storage, no permission needed). */
object MediaSaver {

    enum class Kind { AUDIO, VIDEO, DOWNLOAD }

    fun save(context: Context, src: File, displayName: String, mimeType: String, kind: Kind): Uri {
        val volume = MediaStore.VOLUME_EXTERNAL_PRIMARY
        val (collection, folder) = when (kind) {
            Kind.AUDIO -> MediaStore.Audio.Media.getContentUri(volume) to Environment.DIRECTORY_MUSIC
            Kind.VIDEO -> MediaStore.Video.Media.getContentUri(volume) to Environment.DIRECTORY_MOVIES
            Kind.DOWNLOAD -> MediaStore.Downloads.getContentUri(volume) to Environment.DIRECTORY_DOWNLOADS
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/Sawti")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values) ?: error("Could not create $displayName")
        try {
            resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                ?: error("Could not write $displayName")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }
}
