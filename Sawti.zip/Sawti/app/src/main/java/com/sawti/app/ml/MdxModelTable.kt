package com.sawti.app.ml

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/** STFT settings of an MDX-Net model. dimT is the frame count (2^dim_t_set). */
data class MdxParams(
    val nFft: Int,
    val dimF: Int,
    val dimT: Int,
    val compensate: Float,
    val primaryIsVocals: Boolean,
)

/**
 * Known UVR MDX-Net models, keyed the same way UVR identifies them: MD5 of the last 10,000 KiB of
 * the .onnx file. Values come from UVR's public model_data.json (vocal and instrumental models only).
 */
object MdxModelTable {

    fun uvrHash(file: File): String {
        val md5 = MessageDigest.getInstance("MD5")
        RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val tail = 10_000L * 1024
            raf.seek(if (len > tail) len - tail else 0)
            val buf = ByteArray(1 shl 16)
            while (true) {
                val n = raf.read(buf)
                if (n <= 0) break
                md5.update(buf, 0, n)
            }
        }
        return md5.digest().joinToString("") { "%02x".format(it) }
    }

    /** Exact match by hash, otherwise a best guess from the input shape and file name. */
    fun lookup(hash: String, dimF: Int, fileName: String): Pair<MdxParams, Boolean> {
        known[hash]?.let { return it to true }
        val vocals = !fileName.lowercase().contains("inst")
        val nFft = when {
            dimF == 3072 && vocals -> 7680
            dimF == 3072 -> 6144
            vocals -> 6144
            else -> 5120
        }
        return MdxParams(nFft, dimF, 256, 1.0f, vocals) to false
    }

    private val known = mapOf(
        "0ddfc0eb5792638ad5dc27850236c246" to MdxParams(6144, 2048, 256, 1.035f, true),
        "1c56ec0224f1d559c42fd6fd2a67b154" to MdxParams(5120, 2048, 256, 1.025f, false),
        "1d64a6d2c30f709b8c9b4ce1366d96ee" to MdxParams(5120, 2048, 256, 1.065f, false),
        "203f2a3955221b64df85a41af87cf8f0" to MdxParams(6144, 3072, 256, 1.035f, false),
        "291c2049608edb52648b96e27eb80e95" to MdxParams(6144, 3072, 256, 1.035f, false),
        "2cdd429caac38f0194b133884160f2c6" to MdxParams(7680, 3072, 256, 1.045f, false),
        "2f5501189a2f6db6349916fabe8c90de" to MdxParams(6144, 2048, 256, 1.035f, true),
        "398580b6d5d973af3120df54cee6759d" to MdxParams(7680, 3072, 256, 1.75f, true),
        "488b3e6f8bd3717d9d7c428476be2d75" to MdxParams(7680, 3072, 256, 1.035f, false),
        "53c4baf4d12c3e6c3831bb8f5b532b93" to MdxParams(7680, 3072, 256, 1.043f, true),
        "55657dd70583b0fedfba5f67df11d711" to MdxParams(6144, 3072, 256, 1.022f, false),
        "5d343409ef0df48c7d78cce9f0106781" to MdxParams(7680, 3072, 256, 1.075f, true),
        "5f6483271e1efb9bfb59e4a3e6d4d098" to MdxParams(6144, 2048, 512, 1.035f, true),
        "6b31de20e84392859a3d09d43f089515" to MdxParams(6144, 2048, 256, 1.035f, true),
        "73492b58195c3b52d34590d5474452f6" to MdxParams(7680, 3072, 256, 1.043f, true),
        "77d07b2667ddf05b9e3175941b4454a0" to MdxParams(7680, 3072, 256, 1.021f, true),
        "867595e9de46f6ab699008295df62798" to MdxParams(7680, 3072, 256, 1.03f, true),
        "8a88db95c7fb5dbe6a095ff2ffb428b1" to MdxParams(5120, 2048, 256, 1.026f, false),
        "94ff780b977d3ca07c7a343dab2e25dd" to MdxParams(6144, 3072, 256, 1.039f, false),
        "970b3f9492014d18fefeedfe4773cb42" to MdxParams(7680, 3072, 256, 1.009f, true),
        "a3cd63058945e777505c01d2507daf37" to MdxParams(6144, 2048, 256, 1.03f, true),
        "b06327a00d5e5fbc7d96e1781bbdb596" to MdxParams(6144, 3072, 256, 1.035f, false),
        "b33d9b3950b6cbf5fe90a32608924700" to MdxParams(7680, 3072, 256, 1.03f, true),
        "b6bccda408a436db8500083ef3491e8b" to MdxParams(7680, 3072, 256, 1.02f, false),
        "b78da4afc6512f98e4756f5977f5c6b9" to MdxParams(7680, 3072, 256, 1.021f, false),
        "cb790d0c913647ced70fc6b38f5bea1a" to MdxParams(5120, 2560, 256, 1.01f, false),
        "cc63408db3d80b4d85b0287d1d7c9632" to MdxParams(6144, 3072, 256, 1.033f, false),
        "ceed671467c1f64ebdfac8a2490d0d52" to MdxParams(7680, 3072, 256, 1.035f, false),
        "d2a1376f310e4f7fa37fb9b5774eb701" to MdxParams(7680, 3072, 256, 1.035f, false),
        "d7bff498db9324db933d913388cba6be" to MdxParams(6144, 2048, 256, 1.035f, true),
        "d94058f8c7f1fae4164868ae8ae66b20" to MdxParams(6144, 2048, 256, 1.035f, true),
        "e5572e58abf111f80d8241d2e44e7fa4" to MdxParams(7680, 3072, 256, 1.028f, false),
        "e7324c873b1f615c35c1967f912db92a" to MdxParams(7680, 3072, 256, 1.03f, true),
        "ead8d05dab12ec571d67549b3aab03fc" to MdxParams(6144, 3072, 256, 1.035f, false),
        "f2df6d6863d8f435436d8b561594ff49" to MdxParams(7680, 3072, 256, 1.035f, false),
    )
}
