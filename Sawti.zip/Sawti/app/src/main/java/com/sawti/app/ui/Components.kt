package com.sawti.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.sawti.app.R
import kotlin.math.max
import kotlin.math.roundToInt

/** One step of the vertical flow: numbered marker on a rail, content beside it. */
@Composable
fun Step(
    number: Int,
    title: String,
    done: Boolean,
    enabled: Boolean = true,
    last: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val rail = c.outlineVariant
    Row(
        Modifier
            .fillMaxWidth()
            .drawBehind {
                // Connector to the next step, drawn under the marker column on the start side.
                if (!last) {
                    val x = 16.dp.toPx().let { if (layoutDirection == LayoutDirection.Ltr) it else size.width - it }
                    drawLine(rail, Offset(x, 36.dp.toPx()), Offset(x, size.height - 4.dp.toPx()), strokeWidth = 1.5.dp.toPx())
                }
            },
    ) {
        Box(
            Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(if (done) c.primary else c.background)
                .border(1.5.dp, if (done) c.primary else c.outline, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (done) {
                Icon(Icons.Rounded.Check, null, tint = c.onPrimary, modifier = Modifier.size(18.dp))
            } else {
                Text(number.toString(), style = MaterialTheme.typography.labelLarge, color = c.onBackground)
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(
            Modifier
                .weight(1f)
                .padding(bottom = if (last) 8.dp else 36.dp)
                .alpha(if (enabled) 1f else 0.5f),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
            content()
        }
    }
}

/** Waveform with the selected range in brass, plus a range slider underneath. Always drawn left-to-right. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaveformRange(
    peaks: FloatArray,
    durationSec: Float,
    range: ClosedFloatingPointRange<Float>,
    onRangeChange: (ClosedFloatingPointRange<Float>) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val selected = c.tertiary
    val idle = c.outlineVariant
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth()) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(76.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(c.surface)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            ) {
                val n = peaks.size
                if (n == 0 || durationSec <= 0f) return@Canvas
                val step = size.width / n
                val mid = size.height / 2
                for (i in 0 until n) {
                    val t = (i + 0.5f) / n * durationSec
                    val h = max(2f, peaks[i] * size.height)
                    val x = i * step + step / 2
                    drawLine(
                        color = if (t in range) selected else idle,
                        start = Offset(x, mid - h / 2),
                        end = Offset(x, mid + h / 2),
                        strokeWidth = max(1.5f, step * 0.55f),
                        cap = StrokeCap.Round,
                    )
                }
            }
            RangeSlider(
                value = range,
                onValueChange = onRangeChange,
                valueRange = 0f..max(durationSec, 0.1f),
                colors = SliderDefaults.colors(
                    thumbColor = selected,
                    activeTrackColor = selected,
                    inactiveTrackColor = idle,
                ),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime(range.start), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text(formatTime(range.endInclusive), style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun PlayButton(playing: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, enabled = enabled) {
        Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        Text(stringResource(if (playing) R.string.pause else R.string.play))
    }
}

@Composable
fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun LevelMeter(level: Float) {
    val c = MaterialTheme.colorScheme
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            Modifier
                .width(88.dp)
                .height(6.dp)
                .clip(CircleShape)
                .background(c.outlineVariant),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(level.coerceIn(0f, 1f))
                    .background(c.tertiary),
            )
        }
    }
}

fun formatTime(seconds: Float): String {
    val s = seconds.roundToInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
