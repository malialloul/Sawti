package com.sawti.app.ml

import ai.onnxruntime.NodeInfo
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import com.sawti.app.ml.core.Half
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.LongBuffer

/** Shared ONNX Runtime environment and session factory. */
object Ort {
    val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    fun open(file: File): OrtSession {
        val opts = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            // XNNPACK speeds up many fp32 ops on ARM; ignore if this ORT build lacks it.
            runCatching { addXnnpack(mapOf("intra_op_num_threads" to "4")) }
        }
        return env.createSession(file.absolutePath, opts)
    }
}

/**
 * Resolves input names across export variants (e.g. "feats" vs "phone") and creates tensors in
 * whatever dtype the model declares (fp32/fp16, int64/int32).
 */
class ModelIO(private val session: OrtSession) {
    val inputs: Map<String, NodeInfo> = session.inputInfo
    val outputs: Map<String, NodeInfo> = session.outputInfo

    fun find(vararg names: String): String? = names.firstOrNull { it in inputs }

    fun info(name: String): TensorInfo = inputs.getValue(name).info as TensorInfo

    fun floats(name: String, data: FloatArray, shape: LongArray): OnnxTensor =
        when (info(name).type) {
            OnnxJavaType.FLOAT16 -> {
                val bb = ByteBuffer.allocateDirect(data.size * 2).order(ByteOrder.nativeOrder())
                for (v in data) bb.putShort(Half.fromFloat(v))
                bb.rewind()
                OnnxTensor.createTensor(Ort.env, bb, shape, OnnxJavaType.FLOAT16)
            }
            else -> OnnxTensor.createTensor(Ort.env, FloatBuffer.wrap(data), shape)
        }

    fun longs(name: String, data: LongArray, shape: LongArray): OnnxTensor =
        when (info(name).type) {
            OnnxJavaType.INT32 -> OnnxTensor.createTensor(Ort.env, IntBuffer.wrap(IntArray(data.size) { data[it].toInt() }), shape)
            else -> OnnxTensor.createTensor(Ort.env, LongBuffer.wrap(data), shape)
        }
}

fun OnnxTensor.readFloats(): FloatArray {
    floatBuffer?.let { fb -> return FloatArray(fb.remaining()).also { fb.get(it) } }
    if (info.type == OnnxJavaType.FLOAT16) {
        val bb = byteBuffer.order(ByteOrder.nativeOrder())
        return FloatArray(bb.remaining() / 2) { Half.toFloat(bb.getShort(it * 2)) }
    }
    error("Unsupported output type ${info.type}")
}

class UnsupportedModelException(message: String) : Exception(message)
