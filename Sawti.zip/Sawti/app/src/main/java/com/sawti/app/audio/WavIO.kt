package com.sawti.app.audio

import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/** Minimal WAV reader/writer. Writes 16-bit mono; reads 16/24/32-bit PCM or 32-bit float, any channel count. */
object WavIO {

    fun write(file: File, audio: PcmAudio) {
        file.parentFile?.mkdirs()
        file.outputStream().buffered().use { write(it, audio) }
    }

    fun write(out: OutputStream, audio: PcmAudio) {
        val dataBytes = audio.samples.size * 2
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray(Charsets.US_ASCII)); h.putInt(36 + dataBytes)
        h.put("WAVE".toByteArray(Charsets.US_ASCII))
        h.put("fmt ".toByteArray(Charsets.US_ASCII)); h.putInt(16)
        h.putShort(1) // PCM
        h.putShort(1) // mono
        h.putInt(audio.sampleRate)
        h.putInt(audio.sampleRate * 2)
        h.putShort(2)
        h.putShort(16)
        h.put("data".toByteArray(Charsets.US_ASCII)); h.putInt(dataBytes)
        out.write(h.array())

        val buf = ByteBuffer.allocate(16384).order(ByteOrder.LITTLE_ENDIAN)
        for (s in audio.samples) {
            if (buf.remaining() < 2) {
                out.write(buf.array(), 0, buf.position()); buf.clear()
            }
            buf.putShort((s.coerceIn(-1f, 1f) * 32767f).roundToInt().toShort())
        }
        out.write(buf.array(), 0, buf.position())
        out.flush()
    }

    fun read(file: File): PcmAudio = read(file.readBytes())

    fun read(bytes: ByteArray): PcmAudio {
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(bytes.size >= 12 && tag(bb, 0) == "RIFF" && tag(bb, 8) == "WAVE") { "Not a WAV file" }
        var pos = 12
        var format = 0; var channels = 0; var rate = 0; var bits = 0
        while (pos + 8 <= bytes.size) {
            val id = tag(bb, pos)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            when (id) {
                "fmt " -> {
                    format = bb.getShort(body).toInt() and 0xffff
                    channels = bb.getShort(body + 2).toInt()
                    rate = bb.getInt(body + 4)
                    bits = bb.getShort(body + 14).toInt()
                    if (format == 0xFFFE && size >= 26) format = bb.getShort(body + 24).toInt() and 0xffff
                }
                "data" -> {
                    require(channels > 0 && rate > 0) { "WAV fmt chunk missing" }
                    val len = minOf(size, bytes.size - body)
                    return PcmAudio(decode(bb, body, len, format, channels, bits), rate)
                }
            }
            pos = body + size + (size and 1)
        }
        error("WAV data chunk missing")
    }

    private fun decode(bb: ByteBuffer, start: Int, len: Int, format: Int, ch: Int, bits: Int): FloatArray {
        val bytesPerSample = bits / 8
        val frames = len / (bytesPerSample * ch)
        val out = FloatArray(frames)
        for (f in 0 until frames) {
            var acc = 0f
            for (c in 0 until ch) {
                val p = start + (f * ch + c) * bytesPerSample
                acc += when {
                    format == 3 && bits == 32 -> bb.getFloat(p)
                    format == 1 && bits == 16 -> bb.getShort(p) / 32768f
                    format == 1 && bits == 24 -> {
                        val v = (bb.get(p).toInt() and 0xff) or ((bb.get(p + 1).toInt() and 0xff) shl 8) or (bb.get(p + 2).toInt() shl 16)
                        v / 8388608f
                    }
                    format == 1 && bits == 32 -> bb.getInt(p) / 2147483648f
                    else -> error("Unsupported WAV format $format/$bits-bit")
                }
            }
            out[f] = acc / ch
        }
        return out
    }

    private fun tag(bb: ByteBuffer, at: Int): String =
        String(ByteArray(4) { bb.get(at + it) }, Charsets.US_ASCII)
}
