package com.sawti.app.ml.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min

/**
 * MDX-Net chunked demixing, ported from UVR / python-audio-separator (MDXSeparator.demix).
 * Input and output are mono 44.1 kHz; the mono signal is fed to both stereo channels.
 * [model] receives a [1, 4, dimF, dimT] spectrogram (L re, L im, R re, R im) and returns the same shape.
 * The returned signal is the model's primary stem *before* the compensate factor.
 */
class MdxDemixer(
    val nFft: Int,
    val dimF: Int,
    val dimT: Int,
    val hop: Int = 1024,
    private val overlap: Double = 0.25,
) {
    val trim = nFft / 2
    val chunk = hop * (dimT - 1)
    private val gen = chunk - 2 * trim
    private val stft = Stft(nFft, hop)
    private val windows = HashMap<Int, FloatArray>()

    init {
        require(gen > 0) { "dim_t too small for n_fft" }
        require(stft.frames(chunk) == dimT)
    }

    fun chunkCount(samples: Int): Int {
        val total = trim + samples + (gen + trim - samples % gen)
        val step = ((1 - overlap) * chunk).toInt()
        return (total + step - 1) / step
    }

    fun demix(mix: FloatArray, model: (FloatArray) -> FloatArray, onProgress: (Float) -> Unit = {}): FloatArray {
        val n = mix.size
        val pad = gen + trim - n % gen
        val total = trim + n + pad
        val mixture = FloatArray(total)
        System.arraycopy(mix, 0, mixture, trim, n)
        val step = ((1 - overlap) * chunk).toInt()
        val result = FloatArray(total)
        val divider = FloatArray(total)
        val count = (total + step - 1) / step
        var done = 0
        var start = 0
        while (start < total) {
            val end = min(start + chunk, total)
            val actual = end - start
            val part = FloatArray(chunk)
            System.arraycopy(mixture, start, part, 0, actual)
            val out = runChunk(part, model)
            val w = windows.getOrPut(actual) { hanning(actual) }
            for (j in 0 until actual) {
                result[start + j] += out[j] * w[j]
                divider[start + j] += w[j]
            }
            done++
            onProgress(done.toFloat() / count)
            start += step
        }
        return FloatArray(n) { i ->
            val d = divider[trim + i]
            if (d > 1e-8f) result[trim + i] / d else 0f
        }
    }

    private fun runChunk(part: FloatArray, model: (FloatArray) -> FloatArray): FloatArray {
        val (re, im) = stft.forward(part, dimF)
        val plane = dimF * dimT
        for (k in 0 until 3) for (t in 0 until dimT) { re[k * dimT + t] = 0f; im[k * dimT + t] = 0f }
        val spec = FloatArray(4 * plane)
        System.arraycopy(re, 0, spec, 0, plane)
        System.arraycopy(im, 0, spec, plane, plane)
        System.arraycopy(re, 0, spec, 2 * plane, plane)
        System.arraycopy(im, 0, spec, 3 * plane, plane)
        val out = model(spec)
        require(out.size == 4 * plane) { "Unexpected separator output size ${out.size}" }
        // The inverse STFT is linear, so averaging the L/R spectra equals averaging the two waveforms.
        val oRe = FloatArray(plane) { (out[it] + out[2 * plane + it]) * 0.5f }
        val oIm = FloatArray(plane) { (out[plane + it] + out[3 * plane + it]) * 0.5f }
        return stft.inverse(oRe, oIm, dimF, dimT, chunk)
    }

    /** numpy.hanning (symmetric). */
    private fun hanning(m: Int): FloatArray =
        if (m == 1) floatArrayOf(1f) else FloatArray(m) { (0.5 - 0.5 * cos(2 * PI * it / (m - 1))).toFloat() }
}
