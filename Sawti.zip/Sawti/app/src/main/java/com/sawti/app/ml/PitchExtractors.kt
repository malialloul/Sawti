package com.sawti.app.ml

import ai.onnxruntime.OnnxTensor
import com.sawti.app.ml.core.PitchMath
import com.sawti.app.ml.core.YinPitchTracker
import java.io.File

/** 16 kHz audio -> F0 in Hz at 100 frames/s (0 = unvoiced). */
interface PitchExtractor : AutoCloseable {
    val name: String
    fun extract(x16: FloatArray): FloatArray
    override fun close() {}
}

class YinPitchExtractor : PitchExtractor {
    override val name = "YIN"
    private val tracker = YinPitchTracker()
    override fun extract(x16: FloatArray) = PitchMath.smooth(tracker.track(x16))
}

/**
 * RMVPE exported to take a raw waveform (voice-changer style). Handles both outputs:
 * direct F0 in Hz, or the 360-bin salience map that needs decoding.
 */
class RmvpePitchExtractor(file: File) : PitchExtractor {
    override val name = "RMVPE"
    private val session = Ort.open(file)
    private val io = ModelIO(session)
    private val waveName: String
    private val waveRank: Int
    private val thresholdName = io.inputs.keys.firstOrNull { "thresh" in it.lowercase() }

    init {
        waveName = io.inputs.keys.firstOrNull { val n = it.lowercase(); "wav" in n || "audio" in n }
            ?: io.inputs.keys.first { it != thresholdName }
        val shape = io.info(waveName).shape
        waveRank = shape.size
        if (waveRank == 3 && shape[1] > 1) {
            session.close()
            throw UnsupportedModelException("This RMVPE export expects a mel spectrogram; use a waveform-input export")
        }
    }

    override fun extract(x16: FloatArray): FloatArray {
        val n = x16.size.toLong()
        val shape = when (waveRank) { 1 -> longArrayOf(n); 3 -> longArrayOf(1, 1, n); else -> longArrayOf(1, n) }
        val tensors = LinkedHashMap<String, OnnxTensor>()
        try {
            tensors[waveName] = io.floats(waveName, x16, shape)
            thresholdName?.let { tensors[it] = io.floats(it, floatArrayOf(0.03f), longArrayOf(1)) }
            session.run(tensors).use { result ->
                val outName = io.outputs.keys.firstOrNull { it.lowercase() == "f0" } ?: io.outputs.keys.first()
                val t = result.get(outName).get() as OnnxTensor
                val values = t.readFloats()
                val f0 = if (t.info.shape.lastOrNull() == 360L) PitchMath.decodeSalience(values) else values
                return PitchMath.smooth(f0)
            }
        } finally {
            tensors.values.forEach { it.close() }
        }
    }

    override fun close() = session.close()
}
