package com.sawti.app.ml.core

import kotlin.math.max
import kotlin.math.min

/**
 * Splits long audio into overlapping chunks (in 10 ms frames) so the models never see more than a
 * few seconds at once, then stitches the outputs back together with linear crossfades.
 */
object Chunking {

    data class Chunk(val coreStart: Int, val coreEnd: Int, val padStart: Int, val padEnd: Int)

    fun plan(total: Int, size: Int, overlap: Int, pad: Int): List<Chunk> {
        require(size > overlap && total > 0)
        val list = ArrayList<Chunk>()
        var start = 0
        while (start < total) {
            var end = min(total, start + size + overlap)
            if (total - end in 1 until size / 4) end = total
            list += Chunk(start, end, max(0, start - pad), min(total, end + pad))
            if (end >= total) break
            start += size
        }
        return list
    }

    /** Copy [from, to) of [x], zero-padding where [x] is shorter. */
    fun sliceOrPad(x: FloatArray, from: Int, to: Int): FloatArray =
        FloatArray(max(0, to - from)) { val j = from + it; if (j in x.indices) x[j] else 0f }

    fun overlapAdd(pieces: List<FloatArray>, starts: List<Int>, total: Int, overlap: Int): FloatArray {
        val out = FloatArray(total)
        for (i in pieces.indices) {
            val p = pieces[i]
            val s = starts[i]
            val fadeIn = i > 0 && overlap > 0
            val fadeOut = i < pieces.lastIndex && overlap > 0
            for (j in p.indices) {
                val pos = s + j
                if (pos >= total) break
                var w = 1f
                if (fadeIn && j < overlap) w *= j.toFloat() / overlap
                if (fadeOut && j >= p.size - overlap) w *= (p.size - j).toFloat() / overlap
                out[pos] += p[j] * w
            }
        }
        return out
    }
}
