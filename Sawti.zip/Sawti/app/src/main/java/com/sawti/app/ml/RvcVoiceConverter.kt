package com.sawti.app.ml

import ai.onnxruntime.OnnxTensor
import com.sawti.app.audio.PcmAudio
import com.sawti.app.audio.Resampler
import com.sawti.app.ml.core.Chunking
import com.sawti.app.ml.core.PitchMath
import java.io.File
import java.util.Random
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * RVC inference on ONNX Runtime. Expects:
 *  - a content encoder (ContentVec, 768-dim for v2),
 *  - a per-voice synthesizer exported to ONNX (voice-changer or RVC-WebUI naming both work),
 *  - optionally RMVPE for pitch; falls back to YIN.
 */
class RvcVoiceConverter(contentFile: File, voiceFile: File, pitchFile: File?) : VoiceConverter {

    private val encoder = ContentEncoder(contentFile)
    private val synth = Ort.open(voiceFile)
    private val io = ModelIO(synth)
    private val pitch: PitchExtractor =
        pitchFile?.let { runCatching { RmvpePitchExtractor(it) }.getOrNull() } ?: YinPitchExtractor()

    private val featsName = io.find("feats", "phone")
        ?: throw UnsupportedModelException("Not an RVC synthesizer (inputs: ${io.inputs.keys})")
    private val lengthName = io.find("p_len", "phone_lengths")
    private val pitchName = io.find("pitch")
    private val pitchfName = io.find("pitchf")
    private val speakerName = io.find("sid", "ds")
    private val noiseName = io.find("rnd")
    private val usesF0 = pitchName != null && pitchfName != null
    private val embDim = io.info(featsName).shape.last().toInt().takeIf { it > 0 } ?: 768
    private val random = Random(1234)

    /** Learned from the first chunk: output samples per 10 ms frame (e.g. 400 for a 40 kHz model). */
    private var samplesPerFrame = 0

    override val description: String
        get() = "RVC ${if (embDim == 768) "v2" else "v1"}, ${if (usesF0) pitch.name else "no pitch"}"

    init {
        val handled = setOfNotNull(featsName, lengthName, pitchName, pitchfName, speakerName, noiseName)
        val unknown = io.inputs.keys - handled
        if (unknown.isNotEmpty()) throw UnsupportedModelException("Unknown synthesizer inputs: $unknown")
    }

    override fun convert(vocals: PcmAudio, settings: ConversionSettings, onProgress: (Float) -> Unit): PcmAudio {
        val x16 = Resampler.resample(vocals, SR16).samples
        val totalFrames = x16.size / HOP
        require(totalFrames >= 20) { "Clip is too short" }

        val plan = Chunking.plan(totalFrames, CHUNK_FRAMES, OVERLAP_FRAMES, PAD_FRAMES)
        val pieces = ArrayList<FloatArray>(plan.size)
        for ((i, c) in plan.withIndex()) {
            val seg = x16.copyOfRange(c.padStart * HOP, c.padEnd * HOP)
            val (out, frames) = runSegment(seg, settings)
            if (samplesPerFrame == 0) samplesPerFrame = (out.size.toFloat() / frames).roundToInt().coerceAtLeast(1)
            val spf = samplesPerFrame
            pieces += Chunking.sliceOrPad(out, (c.coreStart - c.padStart) * spf, (c.coreEnd - c.padStart) * spf)
            onProgress((i + 1f) / plan.size)
        }
        val spf = samplesPerFrame
        val audio = Chunking.overlapAdd(pieces, plan.map { it.coreStart * spf }, totalFrames * spf, OVERLAP_FRAMES * spf)
        return PcmAudio(audio, spf * 100)
    }

    /** Returns raw synthesizer output and the number of 10 ms frames it represents. */
    private fun runSegment(seg: FloatArray, settings: ConversionSettings): Pair<FloatArray, Int> {
        val feats = encoder.encode(seg, embDim)
        val frames = min(feats.frames * 2, seg.size / HOP)
        // RVC upsamples 50 fps content features to 100 fps by repeating each frame.
        val up = FloatArray(frames * embDim)
        for (f in 0 until frames) System.arraycopy(feats.data, (f / 2) * embDim, up, f * embDim, embDim)

        val t = frames.toLong()
        val tensors = LinkedHashMap<String, OnnxTensor>()
        try {
            tensors[featsName] = io.floats(featsName, up, longArrayOf(1, t, embDim.toLong()))
            lengthName?.let { tensors[it] = io.longs(it, longArrayOf(t), longArrayOf(1)) }
            if (pitchName != null && pitchfName != null) {
                val f0 = PitchMath.shift(PitchMath.fitLength(pitch.extract(seg), frames), settings.semitones)
                tensors[pitchName] = io.longs(pitchName, PitchMath.toCoarse(f0), longArrayOf(1, t))
                tensors[pitchfName] = io.floats(pitchfName, f0, longArrayOf(1, t))
            }
            speakerName?.let { tensors[it] = io.longs(it, longArrayOf(settings.speakerId.toLong()), longArrayOf(1)) }
            noiseName?.let {
                val ch = io.info(it).shape.getOrNull(1)?.takeIf { d -> d > 0 } ?: 192L
                val noise = FloatArray((ch * t).toInt()) { random.nextGaussian().toFloat() }
                tensors[it] = io.floats(it, noise, longArrayOf(1, ch, t))
            }
            synth.run(tensors).use { result ->
                return (result.get(0) as OnnxTensor).readFloats() to frames
            }
        } finally {
            tensors.values.forEach { it.close() }
        }
    }

    override fun close() {
        encoder.close()
        pitch.close()
        synth.close()
    }

    private companion object {
        const val SR16 = 16000
        const val HOP = 160            // 10 ms at 16 kHz
        const val CHUNK_FRAMES = 800   // 8 s per model call keeps memory modest
        const val OVERLAP_FRAMES = 10  // 100 ms crossfade
        const val PAD_FRAMES = 50      // 0.5 s of context on each side
    }
}
