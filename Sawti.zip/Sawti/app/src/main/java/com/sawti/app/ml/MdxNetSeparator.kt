package com.sawti.app.ml

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.TensorInfo
import com.sawti.app.audio.PcmAudio
import com.sawti.app.audio.Resampler
import com.sawti.app.ml.core.MdxDemixer
import java.io.File
import java.nio.FloatBuffer

/**
 * Vocal / music separation with a UVR MDX-Net ONNX model (e.g. Kim_Vocal_2.onnx).
 * The secondary stem is the mix minus the model's primary stem, as in UVR.
 */
class MdxNetSeparator(file: File, private val params: MdxParams) : VocalSeparator {
    private val session = Ort.open(file)
    private val inputName = session.inputNames.first()
    private val dimF: Int
    private val dimT: Int

    init {
        val shape = (session.inputInfo.getValue(inputName).info as TensorInfo).shape
        if (shape.size != 4 || shape[1] != 4L) {
            session.close()
            throw UnsupportedModelException("Not an MDX-Net model (input ${shape.contentToString()})")
        }
        dimF = shape[2].toInt().takeIf { it > 0 } ?: params.dimF
        dimT = shape[3].toInt().takeIf { it > 0 } ?: params.dimT
    }

    private val demixer = MdxDemixer(params.nFft, dimF, dimT)

    override fun separate(song: PcmAudio, onProgress: (Float) -> Unit): Separated {
        val mix = Resampler.resample(song, SAMPLE_RATE).samples
        val primary = demixer.demix(mix, ::runModel, onProgress)
        for (i in primary.indices) primary[i] *= params.compensate
        val other = FloatArray(mix.size) { mix[it] - primary[it] }
        val vocals = if (params.primaryIsVocals) primary else other
        val music = if (params.primaryIsVocals) other else primary
        return Separated(PcmAudio(vocals, SAMPLE_RATE), PcmAudio(music, SAMPLE_RATE))
    }

    private fun runModel(spec: FloatArray): FloatArray {
        val shape = longArrayOf(1, 4, dimF.toLong(), dimT.toLong())
        OnnxTensor.createTensor(Ort.env, FloatBuffer.wrap(spec), shape).use { input ->
            session.run(mapOf(inputName to input)).use { result ->
                return (result.get(0) as OnnxTensor).readFloats()
            }
        }
    }

    override fun close() = session.close()

    companion object {
        const val SAMPLE_RATE = 44100

        /** Reads the input height (dim_f) without keeping the session open. */
        fun probeDimF(file: File): Int = Ort.open(file).use { s ->
            val shape = (s.inputInfo.values.first().info as TensorInfo).shape
            if (shape.size != 4 || shape[1] != 4L) throw UnsupportedModelException("Not an MDX-Net model")
            shape[2].toInt()
        }
    }
}
