package com.sawti.app.ml

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File

enum class ModelSlot(val fileName: String, val required: Boolean) {
    VOICE("voice_rvc.onnx", true),
    CONTENT("content_encoder.onnx", true),
    PITCH("pitch_rmvpe.onnx", false),
    SEPARATOR("separator_mdx.onnx", false),
}

/** Keeps imported ONNX models in app-private storage. Nothing leaves the phone. */
class ModelStore(private val context: Context) {
    private val dir = File(context.filesDir, "models").apply { mkdirs() }
    private val separatorInfo = File(dir, "separator_mdx.json")

    fun file(slot: ModelSlot) = File(dir, slot.fileName)

    fun sizeMb(slot: ModelSlot): Int? = file(slot).takeIf { it.length() > 0 }?.let { (it.length() / 1_048_576).toInt() }

    fun has(slot: ModelSlot) = file(slot).length() > 0

    fun isReady(): Boolean = ModelSlot.entries.filter { it.required }.all { has(it) }

    /**
     * Copies the picked file in and checks ONNX Runtime can open it.
     * Returns false when a separator model wasn't recognised and its settings were guessed.
     */
    fun import(slot: ModelSlot, uri: Uri): Boolean {
        val tmp = File(dir, slot.fileName + ".part")
        context.contentResolver.openInputStream(uri)?.use { input ->
            tmp.outputStream().use { input.copyTo(it, 1 shl 20) }
        } ?: error("Cannot read file")
        var known = true
        try {
            if (slot == ModelSlot.SEPARATOR) {
                val dimF = MdxNetSeparator.probeDimF(tmp)
                val (params, exact) = MdxModelTable.lookup(MdxModelTable.uvrHash(tmp), dimF, displayName(uri))
                known = exact
                separatorInfo.writeText(
                    JSONObject()
                        .put("nFft", params.nFft).put("dimF", params.dimF).put("dimT", params.dimT)
                        .put("compensate", params.compensate.toDouble()).put("vocals", params.primaryIsVocals)
                        .toString(),
                )
            } else {
                Ort.open(tmp).close()
            }
        } catch (e: UnsupportedModelException) {
            tmp.delete()
            throw e
        } catch (e: Exception) {
            tmp.delete()
            throw UnsupportedModelException("Not a valid ONNX model")
        }
        val dest = file(slot)
        dest.delete()
        check(tmp.renameTo(dest)) { "Could not save model" }
        return known
    }

    fun createConverter(): VoiceConverter = RvcVoiceConverter(
        contentFile = file(ModelSlot.CONTENT),
        voiceFile = file(ModelSlot.VOICE),
        pitchFile = file(ModelSlot.PITCH).takeIf { it.length() > 0 },
    )

    fun createSeparator(): VocalSeparator {
        val o = JSONObject(separatorInfo.readText())
        val params = MdxParams(
            nFft = o.getInt("nFft"),
            dimF = o.getInt("dimF"),
            dimT = o.getInt("dimT"),
            compensate = o.getDouble("compensate").toFloat(),
            primaryIsVocals = o.getBoolean("vocals"),
        )
        return MdxNetSeparator(file(ModelSlot.SEPARATOR), params)
    }

    private fun displayName(uri: Uri): String =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: ""
}
