package com.sawti.app.audio

/** Mono PCM audio, samples in [-1, 1]. */
class PcmAudio(val samples: FloatArray, val sampleRate: Int) {
    val durationSec: Double get() = samples.size.toDouble() / sampleRate

    fun slice(startSec: Double, endSec: Double): PcmAudio {
        val s = (startSec * sampleRate).toInt().coerceIn(0, samples.size)
        val e = (endSec * sampleRate).toInt().coerceIn(s, samples.size)
        return PcmAudio(samples.copyOfRange(s, e), sampleRate)
    }
}

/** Growable float buffer used while decoding or recording. */
class FloatArrayBuilder(initialCapacity: Int = 1 shl 16) {
    private var data = FloatArray(maxOf(initialCapacity, 16))
    var size = 0
        private set

    fun add(v: Float) {
        ensure(size + 1)
        data[size++] = v
    }

    fun addAll(src: FloatArray, offset: Int = 0, length: Int = src.size - offset) {
        ensure(size + length)
        System.arraycopy(src, offset, data, size, length)
        size += length
    }

    private fun ensure(capacity: Int) {
        if (capacity <= data.size) return
        var n = data.size * 2
        while (n < capacity) n *= 2
        data = data.copyOf(n)
    }

    fun toArray(): FloatArray = data.copyOf(size)
}
