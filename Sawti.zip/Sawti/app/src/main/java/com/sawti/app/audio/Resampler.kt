package com.sawti.app.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Polyphase windowed-sinc resampler. No trig in the inner loop, so it is fast enough for minutes of audio. */
object Resampler {

    fun resample(audio: PcmAudio, targetRate: Int): PcmAudio =
        if (audio.sampleRate == targetRate) audio
        else PcmAudio(resample(audio.samples, audio.sampleRate, targetRate), targetRate)

    fun resample(x: FloatArray, inRate: Int, outRate: Int, quality: Int = 16): FloatArray {
        if (inRate == outRate || x.isEmpty()) return x.copyOf()
        val g = gcd(inRate, outRate)
        val up = outRate / g
        val down = inRate / g
        val cutoff = min(1.0, up.toDouble() / down) * 0.94
        val half = ceil(quality / cutoff).toInt()
        val taps = 2 * half

        val table = Array(up) { p ->
            val frac = p.toDouble() / up
            val row = DoubleArray(taps)
            var sum = 0.0
            for (k in 0 until taps) {
                val t = (k - half + 1) - frac
                val w = hann(t / half) * sinc(cutoff * t)
                row[k] = w; sum += w
            }
            FloatArray(taps) { (row[it] / sum).toFloat() }
        }

        val outLen = (x.size.toLong() * up / down).toInt()
        val out = FloatArray(outLen)
        for (i in 0 until outLen) {
            val pos = i.toLong() * down
            val n0 = (pos / up).toInt()
            val row = table[(pos % up).toInt()]
            val base = n0 - half + 1
            var acc = 0f
            if (base >= 0 && base + taps <= x.size) {
                for (k in 0 until taps) acc += x[base + k] * row[k]
            } else {
                for (k in 0 until taps) {
                    val j = base + k
                    if (j >= 0 && j < x.size) acc += x[j] * row[k]
                }
            }
            out[i] = acc
        }
        return out
    }

    private fun sinc(t: Double): Double = if (abs(t) < 1e-9) 1.0 else sin(PI * t) / (PI * t)
    private fun hann(u: Double): Double = if (abs(u) >= 1.0) 0.0 else 0.5 * (1.0 + cos(PI * u))
    private tailrec fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)
}
