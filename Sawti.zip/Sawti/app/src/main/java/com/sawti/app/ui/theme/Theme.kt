package com.sawti.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Deep teal ink with a brass accent (the rim of a daff); brass is reserved for audio: waveforms and trim handles.
private val LightColors = lightColorScheme(
    primary = Color(0xFF1E5A55),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFCFE6E1),
    onPrimaryContainer = Color(0xFF0B2B28),
    secondary = Color(0xFF4F6461),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD9E4E1),
    onSecondaryContainer = Color(0xFF14211F),
    tertiary = Color(0xFFA9781C),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFEEF2EF),
    onBackground = Color(0xFF14211F),
    surface = Color(0xFFF8FAF8),
    onSurface = Color(0xFF14211F),
    onSurfaceVariant = Color(0xFF55625F),
    outline = Color(0xFF8A9693),
    outlineVariant = Color(0xFFC9D2CF),
    error = Color(0xFFB3261E),
    onError = Color(0xFFFFFFFF),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF86CFC4),
    onPrimary = Color(0xFF00332E),
    primaryContainer = Color(0xFF1E4D48),
    onPrimaryContainer = Color(0xFFCFE6E1),
    secondary = Color(0xFFB4C9C5),
    onSecondary = Color(0xFF1F3330),
    secondaryContainer = Color(0xFF2A3634),
    onSecondaryContainer = Color(0xFFD9E4E1),
    tertiary = Color(0xFFE0B458),
    onTertiary = Color(0xFF3F2C00),
    background = Color(0xFF0F1716),
    onBackground = Color(0xFFE2EAE8),
    surface = Color(0xFF151E1D),
    onSurface = Color(0xFFE2EAE8),
    onSurfaceVariant = Color(0xFFA5B3B0),
    outline = Color(0xFF6F7C79),
    outlineVariant = Color(0xFF34403E),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410),
)

// Arabic script needs more vertical room than Latin; line heights are set generously.
private val base = Typography()
private val SawtiTypography = base.copy(
    displaySmall = TextStyle(fontSize = 40.sp, lineHeight = 52.sp, fontWeight = FontWeight.Medium),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 15.sp, lineHeight = 24.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 27.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 25.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun SawtiTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = SawtiTypography,
        content = content,
    )
}
