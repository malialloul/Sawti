package com.sawti.app.ml.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Mixed-radix complex FFT (Stockham autosort) for any size. Fast for sizes built from 2, 3 and 5,
 * which covers every MDX-Net n_fft (4096, 5120, 6144, 7680, 8192, 16384).
 * Not thread-safe: each thread should use its own instance.
 */
class Fft(val n: Int) {
    private val cosT = DoubleArray(n) { cos(2 * PI * it / n) }
    private val sinT = DoubleArray(n) { -sin(2 * PI * it / n) } // table of e^(-2*pi*i*t/n)
    private val factors = factorize(n)
    private val tmpRe = DoubleArray(n)
    private val tmpIm = DoubleArray(n)
    private val maxP = factors.maxOrNull() ?: 1
    private val vr = DoubleArray(maxP)
    private val vi = DoubleArray(maxP)

    /** In-place forward DFT: X[k] = sum x[j] e^(-2*pi*i*jk/n). */
    fun forward(re: DoubleArray, im: DoubleArray) {
        var sRe = re; var sIm = im
        var dRe = tmpRe; var dIm = tmpIm
        var ns = 1
        for (p in factors) {
            val stride = n / p
            val tw = n / (ns * p)
            val pStep = n / p
            for (j in 0 until stride) {
                val k = j % ns
                for (r in 0 until p) {
                    var xr = sRe[j + r * stride]
                    var xi = sIm[j + r * stride]
                    if (r != 0 && k != 0) {
                        val t = r * k * tw
                        val c = cosT[t]; val s = sinT[t]
                        val nr = xr * c - xi * s
                        xi = xr * s + xi * c
                        xr = nr
                    }
                    vr[r] = xr; vi[r] = xi
                }
                val base = (j / ns) * ns * p + k
                when (p) {
                    2 -> {
                        dRe[base] = vr[0] + vr[1]; dIm[base] = vi[0] + vi[1]
                        dRe[base + ns] = vr[0] - vr[1]; dIm[base + ns] = vi[0] - vi[1]
                    }
                    4 -> {
                        val ar = vr[0] + vr[2]; val ai = vi[0] + vi[2]
                        val br = vr[0] - vr[2]; val bi = vi[0] - vi[2]
                        val cr = vr[1] + vr[3]; val ci = vi[1] + vi[3]
                        val dr = vr[1] - vr[3]; val di = vi[1] - vi[3]
                        dRe[base] = ar + cr; dIm[base] = ai + ci
                        dRe[base + ns] = br + di; dIm[base + ns] = bi - dr        // b - i*d
                        dRe[base + 2 * ns] = ar - cr; dIm[base + 2 * ns] = ai - ci
                        dRe[base + 3 * ns] = br - di; dIm[base + 3 * ns] = bi + dr // b + i*d
                    }
                    else -> for (q in 0 until p) {
                        var sr = 0.0; var si = 0.0
                        for (r in 0 until p) {
                            val t = ((r * q) % p) * pStep
                            val c = cosT[t]; val s = sinT[t]
                            sr += vr[r] * c - vi[r] * s
                            si += vr[r] * s + vi[r] * c
                        }
                        dRe[base + q * ns] = sr; dIm[base + q * ns] = si
                    }
                }
            }
            ns *= p
            val a = sRe; sRe = dRe; dRe = a
            val b = sIm; sIm = dIm; dIm = b
        }
        if (sRe !== re) {
            System.arraycopy(sRe, 0, re, 0, n)
            System.arraycopy(sIm, 0, im, 0, n)
        }
    }

    /** In-place inverse DFT, scaled by 1/n. */
    fun inverse(re: DoubleArray, im: DoubleArray) {
        for (i in 0 until n) im[i] = -im[i]
        forward(re, im)
        val s = 1.0 / n
        for (i in 0 until n) { re[i] *= s; im[i] = -im[i] * s }
    }

    private companion object {
        fun factorize(n: Int): IntArray {
            require(n >= 1)
            val out = ArrayList<Int>()
            var m = n
            while (m % 4 == 0) { out += 4; m /= 4 }
            for (p in intArrayOf(2, 3, 5)) while (m % p == 0) { out += p; m /= p }
            var p = 7
            while (m > 1) {
                while (m % p == 0) { out += p; m /= p }
                p += 2
            }
            return out.toIntArray()
        }
    }
}
