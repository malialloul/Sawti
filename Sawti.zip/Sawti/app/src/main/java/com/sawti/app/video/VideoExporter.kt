package com.sawti.app.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Builds a vertical 720x1280 MP4 from one still image plus the finished audio, on-device with Media3. */
object VideoExporter {

    /** Must be called on the main thread (Transformer needs a Looper). */
    @OptIn(UnstableApi::class)
    suspend fun export(
        context: Context,
        image: Uri,
        imageMime: String?,
        audio: File,
        durationMs: Long,
        output: File,
    ) = suspendCancellableCoroutine { cont ->
        output.delete()
        val imageItem = MediaItem.Builder()
            .setUri(image)
            .setImageDurationMs(durationMs)
            .apply { if (imageMime != null) setMimeType(imageMime) }
            .build()
        val video = EditedMediaItem.Builder(imageItem)
            .setFrameRate(30)
            .setEffects(
                Effects(
                    emptyList(),
                    listOf(Presentation.createForWidthAndHeight(720, 1280, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)),
                ),
            )
            .build()
        val sound = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(audio))).build()
        val composition = Composition.Builder(
            EditedMediaItemSequence(video),
            EditedMediaItemSequence(sound),
        ).build()

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    cont.resume(Unit)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    cont.resumeWithException(exportException)
                }
            })
            .build()
        transformer.start(composition, output.absolutePath)
        cont.invokeOnCancellation { transformer.cancel() }
    }
}

/** Simple generated cover used when the user doesn't pick a photo. */
object CoverArt {
    fun generate(file: File, title: String, peaks: FloatArray, background: Int, accent: Int, text: Int): File {
        val w = 720
        val h = 1280
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(background)

        val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
        val left = 80f
        val width = w - 2 * left
        val mid = h * 0.52f
        val n = peaks.size.coerceAtLeast(1)
        val step = width / n
        for (i in peaks.indices) {
            val bh = (peaks[i] * 260f).coerceAtLeast(6f)
            val x = left + i * step
            c.drawRoundRect(RectF(x, mid - bh / 2, x + step * 0.55f, mid + bh / 2), 4f, 4f, bar)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = text
            textSize = 56f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText(title.take(28), w / 2f, h * 0.30f, paint)
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return file
    }
}
