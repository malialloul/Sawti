package com.sawti.app.ml.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** F0 helpers matching the RVC reference pipeline (100 frames/s at 16 kHz, hop 160). */
object PitchMath {
    const val F0_MIN = 50.0
    const val F0_MAX = 1100.0
    private val melMin = 1127.0 * ln(1.0 + F0_MIN / 700.0)
    private val melMax = 1127.0 * ln(1.0 + F0_MAX / 700.0)

    /** RVC "coarse" pitch: mel-scaled bins 1..255 (1 = unvoiced). */
    fun toCoarse(f0: FloatArray): LongArray = LongArray(f0.size) { i ->
        var mel = 1127.0 * ln(1.0 + f0[i] / 700.0)
        if (mel > 0) mel = (mel - melMin) * 254.0 / (melMax - melMin) + 1.0
        Math.rint(mel.coerceIn(1.0, 255.0)).toLong()
    }

    fun shift(f0: FloatArray, semitones: Int): FloatArray {
        if (semitones == 0) return f0
        val k = 2.0.pow(semitones / 12.0).toFloat()
        return FloatArray(f0.size) { f0[it] * k }
    }

    /** Pad (with zeros) or truncate to [n] frames. */
    fun fitLength(f0: FloatArray, n: Int): FloatArray =
        if (f0.size == n) f0 else FloatArray(n) { if (it < f0.size) f0[it] else 0f }

    /** Median over voiced neighbours (radius 2) to remove octave spikes. */
    fun smooth(f0: FloatArray): FloatArray {
        val out = f0.copyOf()
        val win = FloatArray(5)
        for (i in f0.indices) {
            if (f0[i] <= 0f) continue
            var n = 0
            for (j in max(0, i - 2)..min(f0.lastIndex, i + 2)) if (f0[j] > 0f) win[n++] = f0[j]
            win.sort(0, n)
            out[i] = win[n / 2]
        }
        return out
    }

    /** Decode RMVPE 360-bin salience (frames x 360, row-major) into Hz, 0 = unvoiced. */
    fun decodeSalience(sal: FloatArray, bins: Int = 360, threshold: Float = 0.03f): FloatArray {
        val frames = sal.size / bins
        return FloatArray(frames) { f ->
            val base = f * bins
            var arg = 0
            var mx = Float.NEGATIVE_INFINITY
            for (b in 0 until bins) if (sal[base + b] > mx) { mx = sal[base + b]; arg = b }
            if (mx <= threshold) 0f else {
                var num = 0.0
                var den = 0.0
                for (b in max(0, arg - 4)..min(bins - 1, arg + 4)) {
                    val w = sal[base + b].toDouble()
                    num += w * (20.0 * b + 1997.3794084376191)
                    den += w
                }
                if (den <= 0.0) 0f else (10.0 * 2.0.pow(num / den / 1200.0)).toFloat()
            }
        }
    }
}

/**
 * Plain-Kotlin YIN pitch tracker, used when no RMVPE model is installed.
 * Frame i is centred on sample i * hop, like RMVPE/RVC.
 */
class YinPitchTracker(
    private val sampleRate: Int = 16000,
    private val hop: Int = 160,
    private val window: Int = 400,
    fMin: Double = PitchMath.F0_MIN,
    fMax: Double = PitchMath.F0_MAX,
    private val threshold: Double = 0.15,
    private val silenceRms: Double = 0.004,
) {
    private val tauMin = max(2, floor(sampleRate / fMax).toInt())
    private val tauMax = ceil(sampleRate / fMin).toInt()

    fun track(x: FloatArray): FloatArray {
        val frames = x.size / hop
        val out = FloatArray(frames)
        val len = window + tauMax
        val buf = DoubleArray(len)
        val d = DoubleArray(tauMax + 1)
        for (i in 0 until frames) {
            val start = i * hop - len / 2
            var energy = 0.0
            for (k in 0 until len) {
                val idx = start + k
                val v = if (idx >= 0 && idx < x.size) x[idx].toDouble() else 0.0
                buf[k] = v
                energy += v * v
            }
            if (sqrt(energy / len) < silenceRms) continue

            for (tau in 1..tauMax) {
                var s = 0.0
                for (j in 0 until window) {
                    val diff = buf[j] - buf[j + tau]
                    s += diff * diff
                }
                d[tau] = s
            }
            var running = 0.0
            for (tau in 1..tauMax) {
                running += d[tau]
                d[tau] = if (running > 0) d[tau] * tau / running else 1.0
            }
            var tau = tauMin
            var est = -1
            while (tau <= tauMax) {
                if (d[tau] < threshold) {
                    while (tau + 1 <= tauMax && d[tau + 1] < d[tau]) tau++
                    est = tau
                    break
                }
                tau++
            }
            if (est < 0) continue
            val refined = if (est in 1 until tauMax) {
                val s0 = d[est - 1]; val s1 = d[est]; val s2 = d[est + 1]
                val denom = s0 + s2 - 2 * s1
                if (abs(denom) > 1e-12) est + (s0 - s2) / (2 * denom) else est.toDouble()
            } else est.toDouble()
            out[i] = (sampleRate / refined).toFloat()
        }
        return out
    }
}
