// Release signing comes from environment variables (set by the GitHub workflow from repository secrets).
// Without them, the release APK is signed with the debug key so it still installs.
val releaseKeystore = System.getenv("SAWTI_KEYSTORE_FILE")?.let { file(it) }?.takeIf { it.exists() }

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.sawti.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sawti.app"
        minSdk = 29
        targetSdk = 35
        versionCode = System.getenv("SAWTI_VERSION_CODE")?.toIntOrNull() ?: 1
        versionName = System.getenv("SAWTI_VERSION_NAME") ?: "0.1.0"
        // ONNX models need a 64-bit device in practice; x86_64 is for the emulator.
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }

    signingConfigs {
        if (releaseKeystore != null) {
            create("release") {
                storeFile = releaseKeystore
                storePassword = System.getenv("SAWTI_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("SAWTI_KEY_ALIAS")
                keyPassword = System.getenv("SAWTI_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            // Shrinking is off for now: ONNX Runtime is reached through JNI and is easy to break with R8.
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }

    lint {
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // On-device inference
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")

    // On-device video export (FFmpegKit is retired; Media3 Transformer uses the phone's hardware encoders)
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
}
