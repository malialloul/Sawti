# ONNX Runtime is called from native code through JNI.
-keep class ai.onnxruntime.** { *; }
